local ADDON_NAME, ns = ...
ns = ns or {}

local addon = ns.addon
local U = ns.U or {}

if not addon then
    return
end

local function GetDB()
    return U.GetDB and U.GetDB() or nil
end

local EscapeLuaPattern = U.EscapeLuaPattern
local ExtractBracketName = U.ExtractBracketName
local GetItemKeyAndQuery = U.GetItemKeyAndQuery
local IsQuestItemClass = U.IsQuestItemClass
local ShowLootMessage = U.ShowLootMessage
local ShowLootMessageQuest = U.ShowLootMessageQuest

local function NormalizeObjectiveText(text)
    if not text then
        return ""
    end

    text = tostring(text)
    text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
    text = text:gsub("|r", "")
    text = text:gsub("^%s+", "")
    text = text:gsub("%s+$", "")
    text = text:gsub("^[%-%*•]+%s*", "")
    return text
end

local function ScoreQuestObjectiveTextForItem(objectiveText, itemNameLower)
    if not objectiveText or not itemNameLower or itemNameLower == "" then
        return nil
    end

    local normalized = NormalizeObjectiveText(objectiveText)
    local lowered = normalized:lower()
    if not lowered:find(itemNameLower, 1, true) then
        return nil
    end

    if lowered:find("^use%s+") or lowered:find("^activate%s+") or lowered:find("^charge%s+") then
        return nil
    end

    local score = 1
    local escapedName = EscapeLuaPattern and EscapeLuaPattern(itemNameLower) or itemNameLower

    if lowered:find("^" .. escapedName) then
        score = score + 50
    end
    if lowered:find("^collect%s+") or lowered:find("^gather%s+") or lowered:find("^loot%s+") then
        score = score + 40
    end
    if lowered:find(escapedName .. "%s*[:%-–]?%s*%d+%s*/%s*%d+") then
        score = score + 20
    end

    return score
end

local taskQuestCache = { mapID = nil, t = 0, ids = nil }

local function GetNearbyTaskQuestIDs()
    if not C_TaskQuest or not C_TaskQuest.GetQuestsForPlayerByMapID then
        return {}
    end
    if not C_Map or not C_Map.GetBestMapForUnit then
        return {}
    end

    local uiMapID = C_Map.GetBestMapForUnit("player")
    if not uiMapID then
        return {}
    end

    local now = (GetTime and GetTime()) or 0
    if taskQuestCache.ids and taskQuestCache.mapID == uiMapID and (now - (taskQuestCache.t or 0)) < 2.0 then
        return taskQuestCache.ids
    end

    local raw = {}
    local seenMaps = {}

    local function addMap(mapID)
        if not mapID or seenMaps[mapID] then
            return
        end
        seenMaps[mapID] = true

        local ok, pois = pcall(C_TaskQuest.GetQuestsForPlayerByMapID, mapID)
        if ok and type(pois) == "table" then
            for _, poi in ipairs(pois) do
                local questID = poi and (poi.questId or poi.questID)
                if type(questID) == "number" and questID > 0 then
                    raw[#raw + 1] = questID
                end
            end
        end

        if C_Map and C_Map.GetMapInfo then
            local info = C_Map.GetMapInfo(mapID)
            if info and info.parentMapID and info.parentMapID > 0 then
                addMap(info.parentMapID)
            end
        end
    end

    addMap(uiMapID)

    local unique = {}
    local ids = {}
    for _, questID in ipairs(raw) do
        if not unique[questID] then
            unique[questID] = true
            ids[#ids + 1] = questID
        end
    end

    taskQuestCache.ids = ids
    taskQuestCache.mapID = uiMapID
    taskQuestCache.t = now

    return ids
end

local function GetQuestIDsForObjectiveScan()
    local ids = {}

    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
        local ok, numEntries = pcall(C_QuestLog.GetNumQuestLogEntries)
        if ok and numEntries then
            for index = 1, numEntries do
                local info = C_QuestLog.GetInfo(index)
                if info and info.questID and not info.isHeader then
                    ids[#ids + 1] = info.questID
                end
            end
        end
    end

    if type(GetTasksTable) == "function" then
        local ok, tasks = pcall(GetTasksTable)
        if ok and type(tasks) == "table" then
            for _, questID in ipairs(tasks) do
                if type(questID) == "number" and questID > 0 then
                    ids[#ids + 1] = questID
                end
            end
        end
    end

    if C_QuestLog and C_QuestLog.GetQuestsOnMap and C_Map and C_Map.GetBestMapForUnit then
        local uiMapID = C_Map.GetBestMapForUnit("player")
        if uiMapID then
            local ok, quests = pcall(C_QuestLog.GetQuestsOnMap, uiMapID)
            if ok and type(quests) == "table" then
                for _, quest in ipairs(quests) do
                    local questID = (type(quest) == "table" and quest.questID) or quest
                    if type(questID) == "number" and questID > 0 then
                        ids[#ids + 1] = questID
                    end
                end
            end
        end
    end

    if C_QuestLog and C_QuestLog.GetNumWorldQuestWatches and C_QuestLog.GetQuestIDForWorldQuestWatchIndex then
        local ok, count = pcall(C_QuestLog.GetNumWorldQuestWatches)
        if ok and count then
            for index = 1, count do
                local questID = C_QuestLog.GetQuestIDForWorldQuestWatchIndex(index)
                if type(questID) == "number" and questID > 0 then
                    ids[#ids + 1] = questID
                end
            end
        end
    end

    for _, questID in ipairs(GetNearbyTaskQuestIDs()) do
        ids[#ids + 1] = questID
    end

    local unique = {}
    local out = {}
    for _, questID in ipairs(ids) do
        if type(questID) == "number" and questID > 0 and not unique[questID] then
            unique[questID] = true
            out[#out + 1] = questID
        end
    end

    return out
end

local function GetObjectiveKey(questID, objectiveIndex)
    return (tonumber(questID) or 0) .. ":" .. (tonumber(objectiveIndex) or 0)
end

local function GetQuestObjectivesForScan(questID)
    if not C_QuestLog or not C_QuestLog.GetQuestObjectives then
        return nil
    end

    local objectives = C_QuestLog.GetQuestObjectives(questID)
    if (not objectives or #objectives == 0) and C_QuestLog.RequestLoadQuestByID then
        pcall(C_QuestLog.RequestLoadQuestByID, questID)
        objectives = C_QuestLog.GetQuestObjectives(questID)
    end

    return objectives
end

local function GetObjectiveProgressValues(objective)
    local text = objective and objective.text
    local fulfilled = objective and objective.numFulfilled
    local required = objective and objective.numRequired

    if (fulfilled == nil or required == nil) and type(text) == "string" then
        local a, b = text:match("(%d+)%s*/%s*(%d+)")
        if a and b then
            fulfilled = tonumber(a)
            required = tonumber(b)
        end
    end

    return tonumber(fulfilled) or 0, tonumber(required) or 0, text
end

local function IsTaskOrWorldQuest(questID)
    if not questID then
        return false
    end
    if C_QuestLog then
        if C_QuestLog.IsQuestTask and C_QuestLog.IsQuestTask(questID) then
            return true
        end
        if C_QuestLog.IsWorldQuest and C_QuestLog.IsWorldQuest(questID) then
            return true
        end
    end
    return false
end

local function GetObjectiveCacheTable()
    local db = GetDB()
    if not db then
        return nil
    end
    db.taskObjectiveCache = db.taskObjectiveCache or {}
    return db.taskObjectiveCache
end

local function CacheObjectiveProgress(questID, objectiveIndex, fulfilled, required)
    if not IsTaskOrWorldQuest(questID) then
        return
    end

    local cache = GetObjectiveCacheTable()
    if not cache then
        return
    end

    required = tonumber(required) or 0
    fulfilled = tonumber(fulfilled) or 0
    if required <= 0 then
        return
    end

    cache[GetObjectiveKey(questID, objectiveIndex)] = { f = fulfilled, r = required, t = time() }
end

local function GetCachedObjectiveProgress(questID, objectiveIndex)
    local cache = GetObjectiveCacheTable()
    if not cache then
        return nil
    end

    local entry = cache[GetObjectiveKey(questID, objectiveIndex)]
    if entry and entry.f ~= nil and entry.r ~= nil then
        return tonumber(entry.f) or 0, tonumber(entry.r) or 0, tonumber(entry.t) or 0
    end
    return nil
end

local function AdjustObjectiveProgressWithCache(questID, objectiveIndex, fulfilled, required)
    fulfilled = tonumber(fulfilled) or 0
    required = tonumber(required) or 0
    if required <= 0 then
        return fulfilled
    end

    local cachedFulfilled, cachedRequired, cachedTime = GetCachedObjectiveProgress(questID, objectiveIndex)
    if cachedFulfilled and cachedRequired and cachedTime and cachedRequired == required then
        local age = (time() or 0) - (cachedTime or 0)
        if age >= 0 and age <= (12 * 3600) and cachedFulfilled > fulfilled then
            return math.min(required, cachedFulfilled + fulfilled)
        end
    end

    return fulfilled
end

local function PruneObjectiveCache()
    local cache = GetObjectiveCacheTable()
    if not cache then
        return
    end

    local now = time() or 0
    for key, value in pairs(cache) do
        if type(value) ~= "table" or not value.t or (now - value.t) > (2 * 86400) then
            cache[key] = nil
        end
    end

    local keys = {}
    for key, value in pairs(cache) do
        keys[#keys + 1] = { key = key, t = (type(value) == "table" and value.t) or 0 }
    end

    if #keys > 500 then
        table.sort(keys, function(a, b)
            return (a.t or 0) > (b.t or 0)
        end)
        for index = 501, #keys do
            cache[keys[index].key] = nil
        end
    end
end

local function CollectAllQuestObjectives()
    local out = {}
    if not C_QuestLog then
        return out
    end

    for _, questID in ipairs(GetQuestIDsForObjectiveScan()) do
        local objectives = GetQuestObjectivesForScan(questID)
        if objectives and #objectives > 0 then
            for objectiveIndex, objective in ipairs(objectives) do
                local fulfilled, required, text = GetObjectiveProgressValues(objective)
                if required > 0 then
                    CacheObjectiveProgress(questID, objectiveIndex, fulfilled, required)
                    out[#out + 1] = {
                        questID = questID,
                        objIndex = objectiveIndex,
                        fulfilled = fulfilled,
                        required = required,
                        text = text,
                    }
                end
            end
        elseif type(GetQuestObjectiveInfo) == "function" then
            local numObjectives = nil
            if C_QuestLog.GetNumQuestObjectives then
                local ok, count = pcall(C_QuestLog.GetNumQuestObjectives, questID)
                if ok then
                    numObjectives = count
                end
            end
            if (not numObjectives or numObjectives == 0) and type(GetTaskInfo) == "function" then
                local ok, _, _, count = pcall(GetTaskInfo, questID)
                if ok then
                    numObjectives = count
                end
            end
            numObjectives = tonumber(numObjectives) or 0

            if numObjectives > 0 then
                for objectiveIndex = 1, numObjectives do
                    local ok, text, objectiveType, finished, fulfilled, required = pcall(GetQuestObjectiveInfo, questID, objectiveIndex, false)
                    if ok then
                        required = tonumber(required) or 0
                        fulfilled = tonumber(fulfilled) or 0
                        if required > 0 then
                            CacheObjectiveProgress(questID, objectiveIndex, fulfilled, required)
                            out[#out + 1] = {
                                questID = questID,
                                objIndex = objectiveIndex,
                                fulfilled = fulfilled,
                                required = required,
                                text = text,
                                objectiveType = objectiveType,
                            }
                        end
                    end
                end
            end
        end
    end

    return out
end

local function BuildObjectiveSnapshot(objectives)
    local snapshot = {}
    for _, objective in ipairs(objectives or {}) do
        snapshot[GetObjectiveKey(objective.questID, objective.objIndex)] = tonumber(objective.fulfilled) or 0
    end
    return snapshot
end

local function PickChangedObjective(snapshot, objectives)
    local picked
    local bestScore = -1

    for _, objective in ipairs(objectives or {}) do
        local key = GetObjectiveKey(objective.questID, objective.objIndex)
        local previous = snapshot[key] or 0
        local current = tonumber(objective.fulfilled) or 0
        local required = tonumber(objective.required) or 0
        local delta = current - previous
        local justCompleted = (required > 0 and current >= required and previous < required)

        if delta > 0 or justCompleted then
            local score = (justCompleted and 100000 or 0) + (delta * 1000) + (current * 10) + required
            if score > bestScore then
                bestScore = score
                picked = {
                    questID = objective.questID or 0,
                    objIndex = objective.objIndex or 0,
                    fulfilled = current,
                    required = required,
                }
            end
        end
    end

    return picked
end

local function BuildObjectivePresenceSet(objectives)
    local set = {}
    for _, objective in ipairs(objectives or {}) do
        set[GetObjectiveKey(objective.questID, objective.objIndex)] = true
    end
    return set
end

local function InferDisappearedObjectiveProgress(snapshotObjectives, snapshot, objectivesNow, amount, scoreKey)
    local present = BuildObjectivePresenceSet(objectivesNow)
    local inferred
    local bestScore = -1

    for _, objective in ipairs(snapshotObjectives or {}) do
        local key = GetObjectiveKey(objective.questID, objective.objIndex)
        if not present[key] then
            local previous = snapshot[key] or (tonumber(objective.fulfilled) or 0)
            local required = tonumber(objective.required) or 0
            if required > 0 and required <= 1000 then
                local assumed = math.min(required, previous + (tonumber(amount) or 1))
                local completes = (assumed >= required and previous < required) and 1 or 0
                local extraScore = scoreKey and (tonumber(objective[scoreKey]) or 0) or 0
                local score = (completes * 100000) + (extraScore * 1000) + (required - previous)
                if score > bestScore then
                    bestScore = score
                    inferred = {
                        questID = objective.questID or 0,
                        objIndex = objective.objIndex or 0,
                        fulfilled = assumed,
                        required = required,
                    }
                end
            end
        end
    end

    return inferred
end

local function CollectQuestObjectiveMatches(itemName)
    if not itemName or not C_QuestLog or not C_QuestLog.GetQuestObjectives then
        return {}
    end

    local wanted = tostring(itemName):lower()
    local matches = {}

    for _, questID in ipairs(GetQuestIDsForObjectiveScan()) do
        local objectives = GetQuestObjectivesForScan(questID)
        if objectives then
            for objectiveIndex, objective in ipairs(objectives) do
                local fulfilled, required, text = GetObjectiveProgressValues(objective)
                local score = ScoreQuestObjectiveTextForItem(text, wanted)
                if score and score >= 30 and required > 0 then
                    matches[#matches + 1] = {
                        questID = questID,
                        objIndex = objectiveIndex,
                        text = text,
                        fulfilled = fulfilled,
                        required = required,
                        score = score,
                    }
                end
            end
        end
    end

    return matches
end

local function PickBestQuestMatch(matches)
    local best
    if not matches then
        return nil
    end

    for _, match in ipairs(matches) do
        local fulfilled = tonumber(match.fulfilled) or 0
        local required = tonumber(match.required) or 0
        local score = tonumber(match.score) or 0
        if required > 0 then
            local incomplete = (fulfilled < required) and 1 or 0
            local remaining = required - fulfilled

            if (not best)
                or (score > best.score)
                or (score == best.score and incomplete > best.incomplete)
                or (score == best.score and incomplete == best.incomplete and remaining < best.remaining)
                or (score == best.score and incomplete == best.incomplete and remaining == best.remaining and required > best.required)
                or (score == best.score and incomplete == best.incomplete and remaining == best.remaining and required == best.required and fulfilled > best.fulfilled)
            then
                best = {
                    fulfilled = fulfilled,
                    required = required,
                    incomplete = incomplete,
                    remaining = remaining,
                    score = score,
                }
            end
        end
    end

    return best
end

function addon.GetQuestProgressForItem(itemName)
    if not itemName then
        return nil
    end

    local best = PickBestQuestMatch(CollectQuestObjectiveMatches(itemName))
    if best then
        return best.fulfilled or 0, best.required
    end

    return nil
end

function addon.TryShowQuestLootProgress(itemText, amount, progress)
    if not progress or not progress.required or progress.required <= 0 then
        return false
    end

    local fulfilled = AdjustObjectiveProgressWithCache(progress.questID or 0, progress.objIndex or 0, progress.fulfilled, progress.required)
    ShowLootMessageQuest(itemText, amount, fulfilled, progress.required)
    return true
end

function addon.InferObjectiveProgressFromSnapshotEntry(entry, snapshot, amount)
    if type(entry) ~= "table" then
        return nil
    end

    local required = tonumber(entry.required) or 0
    if required <= 0 or required > 1000 then
        return nil
    end

    local key = GetObjectiveKey(entry.questID, entry.objIndex)
    local previous = snapshot[key] or (tonumber(entry.fulfilled) or 0)

    return {
        questID = entry.questID or 0,
        objIndex = entry.objIndex or 0,
        fulfilled = math.min(required, previous + (tonumber(amount) or 1)),
        required = required,
    }, previous
end

function addon.PickBestInferredObjectiveProgress(entries, snapshot, amount, scoreKey)
    local best
    local bestScore = -1

    for _, entry in ipairs(entries or {}) do
        local inferred, previous = addon.InferObjectiveProgressFromSnapshotEntry(entry, snapshot, amount)
        if inferred then
            local completes = (inferred.fulfilled >= inferred.required and previous < inferred.required) and 1 or 0
            local extraScore = scoreKey and (tonumber(entry[scoreKey]) or 0) or 0
            local score = (completes * 100000) + (extraScore * 1000) + (inferred.required - previous)
            if score > bestScore then
                bestScore = score
                best = inferred
            end
        end
    end

    return best
end

local pendingQuestLootBatches = {}
local QUEST_LOOT_BATCH_DELAY = 0.40
local QUEST_LOOT_RETRY_DELAY = 0.18
local QUEST_LOOT_MAX_RETRIES = 5

function addon.ResetQuestLootBatchState()
    if wipe then
        wipe(pendingQuestLootBatches)
    else
        for key in pairs(pendingQuestLootBatches) do
            pendingQuestLootBatches[key] = nil
        end
    end
    PruneObjectiveCache()
end

local function GetQuestBatchKey(itemText, itemName, itemID)
    if itemID then
        return "item:" .. tostring(itemID)
    end

    if itemName and itemName ~= "" then
        return "name:" .. tostring(itemName):lower()
    end

    return "text:" .. tostring(itemText or "")
end

local function AddNamedSnapshotToBatch(batch, namedMatches)
    if namedMatches and #namedMatches > 0 and (not batch.namedMatches or #batch.namedMatches == 0) then
        batch.namedMatches = namedMatches
        batch.namedSnapshot = BuildObjectiveSnapshot(namedMatches)
    end
end

local function AddBroadSnapshotToBatch(batch)
    if batch.broadSnapshotObjectives then
        return
    end

    local objectives = CollectAllQuestObjectives()
    if objectives and #objectives > 0 then
        batch.broadSnapshotObjectives = objectives
        batch.broadSnapshot = BuildObjectiveSnapshot(objectives)
    end
end

local function ResolveNamedQuestBatch(batch)
    if not batch.namedMatches or #batch.namedMatches == 0 then
        return false
    end

    local currentMatches = CollectQuestObjectiveMatches(batch.itemName)
    local progress = PickChangedObjective(batch.namedSnapshot or {}, currentMatches)

    if not progress and batch.attempt >= QUEST_LOOT_MAX_RETRIES then
        progress = InferDisappearedObjectiveProgress(batch.namedMatches, batch.namedSnapshot or {}, currentMatches, batch.amount, "score")
        if not progress then
            progress = addon.PickBestInferredObjectiveProgress(batch.namedMatches, batch.namedSnapshot or {}, batch.amount, "score")
        end
    end

    return addon.TryShowQuestLootProgress(batch.itemText, batch.amount, progress)
end

local function ResolveBroadQuestBatch(batch)
    if not batch.broadSnapshotObjectives or #batch.broadSnapshotObjectives == 0 then
        return false
    end

    local currentObjectives = CollectAllQuestObjectives()
    local progress = PickChangedObjective(batch.broadSnapshot or {}, currentObjectives)

    if not progress and batch.attempt >= QUEST_LOOT_MAX_RETRIES then
        progress = InferDisappearedObjectiveProgress(batch.broadSnapshotObjectives, batch.broadSnapshot or {}, currentObjectives, batch.amount)
    end

    return addon.TryShowQuestLootProgress(batch.itemText, batch.amount, progress)
end

local function FlushQuestLootBatch(batchKey, expectedSequence)
    local batch = pendingQuestLootBatches[batchKey]
    if not batch or batch.sequence ~= expectedSequence then
        return
    end

    batch.attempt = (batch.attempt or 0) + 1

    if ResolveNamedQuestBatch(batch) or ResolveBroadQuestBatch(batch) then
        pendingQuestLootBatches[batchKey] = nil
        return
    end

    if batch.attempt < QUEST_LOOT_MAX_RETRIES then
        addon.ScheduleAfter(QUEST_LOOT_RETRY_DELAY, function()
            FlushQuestLootBatch(batchKey, batch.sequence)
        end)
        return
    end

    pendingQuestLootBatches[batchKey] = nil
    ShowLootMessage(batch.itemText, batch.amount)
end

local function QueueQuestLootBatch(itemText, itemName, itemID, amount, namedMatches, isQuestClass)
    if not addon.CanScheduleTimer() then
        return false
    end

    local batchKey = GetQuestBatchKey(itemText, itemName, itemID)
    local batch = pendingQuestLootBatches[batchKey]

    if batch then
        batch.itemText = itemText or batch.itemText
        batch.itemName = itemName or batch.itemName
        batch.itemID = itemID or batch.itemID
        batch.amount = (batch.amount or 0) + (tonumber(amount) or 1)
        batch.sequence = (batch.sequence or 0) + 1
        batch.attempt = 0

        AddNamedSnapshotToBatch(batch, namedMatches)
        if isQuestClass then
            AddBroadSnapshotToBatch(batch)
        end
    else
        batch = {
            itemText = itemText,
            itemName = itemName,
            itemID = itemID,
            amount = tonumber(amount) or 1,
            sequence = 1,
            attempt = 0,
        }

        AddNamedSnapshotToBatch(batch, namedMatches)
        if isQuestClass then
            AddBroadSnapshotToBatch(batch)
        end

        pendingQuestLootBatches[batchKey] = batch
    end

    local sequence = batch.sequence
    addon.ScheduleAfter(QUEST_LOOT_BATCH_DELAY, function()
        FlushQuestLootBatch(batchKey, sequence)
    end)
    return true
end

local function HasQuestMatches(matches)
    return type(matches) == "table" and #matches > 0
end

function addon.HandleLootChatMessage(itemText, amount)
    amount = tonumber(amount) or 1

    local db = GetDB()
    local _, itemQuery = GetItemKeyAndQuery(itemText)
    local itemID = type(itemQuery) == "number" and itemQuery or nil
    local itemName = ExtractBracketName(itemText) or itemText
    local namedMatches = CollectQuestObjectiveMatches(itemName)
    local hasNamedMatches = HasQuestMatches(namedMatches)
    local isQuestClass = IsQuestItemClass(itemID)
    local isQuestTrackedLoot = hasNamedMatches or isQuestClass

    if db and db.showQuestItems == false and isQuestTrackedLoot then
        return
    end

    if isQuestTrackedLoot and QueueQuestLootBatch(itemText, itemName, itemID, amount, namedMatches, isQuestClass) then
        return
    end

    ShowLootMessage(itemText, amount)
end
