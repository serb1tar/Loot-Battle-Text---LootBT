local ADDON_NAME, ns = ...
ns = ns or {}

local addon = ns.addon
if not addon then
    addon = CreateFrame("Frame")
    ns.addon = addon
end

ns.U = ns.U or {}
_G[ADDON_NAME] = addon
