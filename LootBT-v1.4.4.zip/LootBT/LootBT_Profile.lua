local ADDON_NAME, ns = ...
ns = ns or {}

local addon = ns.addon
local U = ns.U or {}
if not addon then
    return
end

local function GetDB()
    return U.GetDB and U.GetDB() or nil
end

local db = setmetatable({}, {
    __index = function(_, key)
        local real = GetDB()
        if real then
            return real[key]
        end
    end,
    __newindex = function(_, key, value)
        local real = GetDB()
        if real then
            real[key] = value
        end
    end,
})

local defaults = addon.GetDefaults and addon.GetDefaults() or {}
local DeepCopy = U.DeepCopy
local Print = U.Print
local SanitizeRuntimeConfig = U.SanitizeRuntimeConfig
local SetColorForKey = U.SetColorForKey

local PROFILE_PREFIX = "LBT1"
local PROFILE_OBF_PREFIX = "LBT1:"
local PROFILE_OBF_PREFIX_SAFE = "LBTX:"
local DEFAULT_PROFILE_NAME = "Default"
local PROFILE_BOOL_KEYS = {
    "showLoot", "showQuestItems", "showLootIcons", "showLootTotals", "showUpgradeArrow", "showMoney", "showMoneyIcons", "showCurrency", "showCombat", "showHonor", "showReputation", "showDelveCompanionXP", "showSkill",
    "hideGreys", "useIndividualFonts", "stripAutoSymbols",
}
local PROFILE_NUM_KEYS = {
    "lootDuration", "scrollDuration", "fontSize", "maxStacked", "maxScrollVisible",
    "stackPadding", "scrollPadding",
    "lootScale", "scrollScale",
    "stackAnchorX", "stackAnchorY", "scrollAnchorX", "scrollAnchorY",
}
local PROFILE_STR_KEYS = { "combatEnterText", "combatLeaveText", "globalFont", "lootFont", "moneyFont", "currencyFont", "combatEnterFont", "combatLeaveFont", "honorFont", "repGainFont", "repLossFont", "skillFont" }
local PROFILE_COLOR_KEYS = {
    "loot", "money", "currency", "combatEnter", "combatLeave", "honor", "repGain", "repLoss", "skill",
}
local PROFILE_IGNORED_KEYS = {
    showAnchors = true,
    showMinimap = true,
    minimapPos = true,
}
local currentCharacterKey

local function URLEncode(str)
    str = tostring(str or "")
    return (str:gsub("([^%w%-_%.~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end

local function URLDecode(str)
    str = tostring(str or "")
    return (str:gsub("%%(%x%x)", function(h)
        return string.char(tonumber(h, 16) or 32)
    end))
end

local function SplitPipe(text)
    local out = {}
    text = tostring(text or "")
    for token in text:gmatch("[^|]+") do
        table.insert(out, token)
    end
    return out
end




local _bxor = (bit and bit.bxor) or (bit32 and bit32.bxor)
local function BXOR(a, b)
    if _bxor then
        return _bxor(a, b)
    end
    return (a + b) % 256
end

local _b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
local _b64inv = nil

local function Base64UrlEncode(data)
    data = tostring(data or "")
    local out = {}
    local i = 1
    while i <= #data do
        local a = data:byte(i) or 0
        local b = data:byte(i + 1)
        local c = data:byte(i + 2)
        local pad = 0
        if b == nil then
            b = 0
            c = 0
            pad = 2
        elseif c == nil then
            c = 0
            pad = 1
        end
        local n = a * 65536 + b * 256 + c
        local i1 = math.floor(n / 262144) % 64
        local i2 = math.floor(n / 4096) % 64
        local i3 = math.floor(n / 64) % 64
        local i4 = n % 64

        out[#out + 1] = _b64chars:sub(i1 + 1, i1 + 1)
        out[#out + 1] = _b64chars:sub(i2 + 1, i2 + 1)
        if pad == 2 then
            out[#out + 1] = "="
            out[#out + 1] = "="
        elseif pad == 1 then
            out[#out + 1] = _b64chars:sub(i3 + 1, i3 + 1)
            out[#out + 1] = "="
        else
            out[#out + 1] = _b64chars:sub(i3 + 1, i3 + 1)
            out[#out + 1] = _b64chars:sub(i4 + 1, i4 + 1)
        end

        i = i + 3
    end
    return table.concat(out)
end

local function Base64UrlDecode(text)
    text = tostring(text or ""):gsub("%s+", "")
    if text == "" then return "" end
    if not _b64inv then
        _b64inv = {}
        for i = 1, #_b64chars do
            _b64inv[_b64chars:sub(i, i)] = i - 1
        end
    end

    local out = {}
    local i = 1
    while i <= #text do
        local c1 = text:sub(i, i); i = i + 1
        local c2 = text:sub(i, i); i = i + 1
        local c3 = text:sub(i, i); i = i + 1
        local c4 = text:sub(i, i); i = i + 1

        local p1 = _b64inv[c1]; local p2 = _b64inv[c2]
        if p1 == nil or p2 == nil then return nil end

        local pad = 0
        local p3, p4
        if c3 == "=" then
            pad = 2
            p3 = 0
            p4 = 0
        elseif c4 == "=" then
            pad = 1
            p3 = _b64inv[c3]
            p4 = 0
            if p3 == nil then return nil end
        else
            p3 = _b64inv[c3]
            p4 = _b64inv[c4]
            if p3 == nil or p4 == nil then return nil end
        end

        local n = p1 * 262144 + p2 * 4096 + p3 * 64 + p4
        local a = math.floor(n / 65536) % 256
        local b = math.floor(n / 256) % 256
        local c = n % 256

        out[#out + 1] = string.char(a)
        if pad < 2 then out[#out + 1] = string.char(b) end
        if pad == 0 then out[#out + 1] = string.char(c) end
    end
    return table.concat(out)
end

local function ProfileHash(str)
    local h = 5381
    str = tostring(str or "")
    for i = 1, #str do
        h = (h * 33 + str:byte(i)) % 4294967296
    end
    return h
end

local function ObfuscateProfileString(plain)
    plain = tostring(plain or "")
    return PROFILE_OBF_PREFIX_SAFE .. Base64UrlEncode(plain)
end

local function DeobfuscateProfileString(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")

    local safePrefix = PROFILE_OBF_PREFIX_SAFE:gsub("(%W)", "%%%1")
    local safePayload = text:match("^" .. safePrefix .. "(.+)$")
    if safePayload then
        local decoded = Base64UrlDecode(safePayload)
        if decoded == nil then return nil end
        return decoded
    end

    local legacyPrefix = PROFILE_OBF_PREFIX:gsub("(%W)", "%%%1")
    local hhex, b64 = text:match("^" .. legacyPrefix .. "([0-9a-fA-F]+):(.+)$")
    if not hhex then
        return text
    end
    local h = tonumber(hhex, 16)
    if not h then return nil end
    local payload = Base64UrlDecode(b64)
    if payload == nil then return nil end

    local key = (h % 251) + 1
    local bytes = {}
    for i = 1, #payload do
        local b = payload:byte(i)
        local k = (key + (i * 17)) % 256
        bytes[i] = string.char(BXOR(b, k))
    end
    local plain = table.concat(bytes)
    if ProfileHash(plain) ~= h then
        return nil
    end
    return plain
end



local function GetProfileExportString()
    local parts = { PROFILE_PREFIX }

    for _, key in ipairs(PROFILE_BOOL_KEYS) do
        table.insert(parts, string.format("b:%s:%d", key, (db and db[key]) and 1 or 0))
    end

    for _, key in ipairs(PROFILE_NUM_KEYS) do
        local value = (db and db[key])
        if type(value) ~= "number" then
            value = defaults[key]
        end
        table.insert(parts, string.format("n:%s:%s", key, tostring(value or 0)))
    end

    for _, key in ipairs(PROFILE_STR_KEYS) do
        local value = (db and db[key])
        if type(value) ~= "string" then
            value = defaults[key] or ""
        end
        table.insert(parts, string.format("s:%s:%s", key, URLEncode(value or "")))
    end

    db.colors = db.colors or {}
    for _, key in ipairs(PROFILE_COLOR_KEYS) do
        local c = (db.colors and db.colors[key]) or (defaults.colors or {})[key] or { 1, 1, 1 }
        local r, g, b = tonumber(c[1]) or 1, tonumber(c[2]) or 1, tonumber(c[3]) or 1
        table.insert(parts, string.format("c:%s:%.3f,%.3f,%.3f", key, r, g, b))
    end

    return table.concat(parts, "|")
end

local function GetProfileExportStringObfuscated()
    return ObfuscateProfileString(GetProfileExportString())
end

local function ApplyProfileExportString(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    local decoded = DeobfuscateProfileString(text)
    if not decoded then
        return false, "Invalid LootBT profile string."
    end
    local tokens = SplitPipe(decoded)
    if #tokens < 1 or tokens[1] ~= PROFILE_PREFIX then
        return false, "Not a LootBT profile string."
    end

    db.colors = db.colors or {}

    for i = 2, #tokens do
        local token = tokens[i]
        local kind, key, value = token:match("^(%w+):([^:]+):(.+)$")
        if kind and key and value then
            if kind == "b" then
                if not PROFILE_IGNORED_KEYS[key] then
                    db[key] = (value == "1" or value == "true") and true or false
                end
            elseif kind == "n" then
                if not PROFILE_IGNORED_KEYS[key] then
                    local n = tonumber(value)
                    if n ~= nil then
                        db[key] = n
                    end
                end
            elseif kind == "s" then
                db[key] = URLDecode(value)
            elseif kind == "c" then
                local r, g, b = value:match("^(%-?[%d%.]+),(%-?[%d%.]+),(%-?[%d%.]+)$")
                r, g, b = tonumber(r), tonumber(g), tonumber(b)
                if r and g and b then
                    SetColorForKey(key, r, g, b)
                end
            end
        end
    end

    SanitizeRuntimeConfig()

    if addon.LayoutLootMessages then addon.LayoutLootMessages() end
    addon:UpdateAnchorVisuals()
    addon:RefreshMinimap()
    addon:RefreshConfigUIs()
    return true
end

local function IsReservedProfileName(name)
    return type(name) == "string" and name:lower() == DEFAULT_PROFILE_NAME:lower()
end

local function ApplyManagedDefaults()
    db.showLoot = defaults.showLoot
    db.showQuestItems = defaults.showQuestItems
    db.showLootIcons = defaults.showLootIcons
    db.showLootTotals = defaults.showLootTotals
    db.showUpgradeArrow = defaults.showUpgradeArrow
    db.showMoney = defaults.showMoney
    db.showMoneyIcons = defaults.showMoneyIcons
    db.showCurrency = defaults.showCurrency
    db.showCombat = defaults.showCombat
    db.combatEnterText = defaults.combatEnterText
    db.combatLeaveText = defaults.combatLeaveText
    db.showHonor = defaults.showHonor
    db.showReputation = defaults.showReputation
    db.showDelveCompanionXP = defaults.showDelveCompanionXP
    db.showSkill = defaults.showSkill
    db.hideGreys = defaults.hideGreys
    db.lootDuration = defaults.lootDuration
    db.scrollDuration = defaults.scrollDuration
    db.fontSize = defaults.fontSize
    db.useIndividualFonts = defaults.useIndividualFonts
    db.stripAutoSymbols = defaults.stripAutoSymbols
    db.globalFont = defaults.globalFont
    db.lootFont = defaults.lootFont
    db.moneyFont = defaults.moneyFont
    db.currencyFont = defaults.currencyFont
    db.combatEnterFont = defaults.combatEnterFont
    db.combatLeaveFont = defaults.combatLeaveFont
    db.honorFont = defaults.honorFont
    db.repGainFont = defaults.repGainFont
    db.repLossFont = defaults.repLossFont
    db.skillFont = defaults.skillFont
    db.maxStacked = defaults.maxStacked
    db.maxScrollVisible = defaults.maxScrollVisible
    db.stackPadding = defaults.stackPadding
    db.scrollPadding = defaults.scrollPadding
    db.lootScale = defaults.lootScale
    db.scrollScale = defaults.scrollScale
    db.stackAnchorX = defaults.stackAnchorX
    db.stackAnchorY = defaults.stackAnchorY
    db.scrollAnchorX = defaults.scrollAnchorX
    db.scrollAnchorY = defaults.scrollAnchorY
    db.colors = DeepCopy(defaults.colors or {})
end

local function RefreshAfterManagedDefaults()
    SanitizeRuntimeConfig()
    if U.ResetPredictedCounts then U.ResetPredictedCounts() end
    if addon.LayoutLootMessages then addon.LayoutLootMessages() end
    addon:UpdateAnchorVisuals()
    addon:RefreshConfigUIs()
end

function addon:ApplyDefaultProfile(silent)
    ApplyManagedDefaults()
    db.lastProfile = DEFAULT_PROFILE_NAME
    self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
    RefreshAfterManagedDefaults()

    if not silent then
        Print("Default profile applied.")
    end

    return true
end

function addon:ResetCurrentProfileToDefaults(silent)
    local currentName = db and db.lastProfile
    ApplyManagedDefaults()

    if type(currentName) ~= "string" or currentName == "" or IsReservedProfileName(currentName) then
        db.lastProfile = DEFAULT_PROFILE_NAME
        self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
    else
        db.lastProfile = currentName
        self:RememberProfileForCurrentCharacter(currentName)
    end

    RefreshAfterManagedDefaults()

    if not IsReservedProfileName(db.lastProfile) then
        self:SyncActiveProfile()
    end

    if not silent then
        Print("Current profile reset to defaults.")
    end

    return true
end

function addon:NormalizeProfilesState()
    local profiles = self:EnsureProfilesTable()
    local selections = self:EnsureCharacterProfilesTable()

    local existingDefault = profiles[DEFAULT_PROFILE_NAME]
    if type(existingDefault) == "string" and existingDefault ~= "" then
        local newName = DEFAULT_PROFILE_NAME .. " (Saved)"
        local suffix = 2
        while profiles[newName] do
            newName = string.format("%s (Saved %d)", DEFAULT_PROFILE_NAME, suffix)
            suffix = suffix + 1
        end
        profiles[newName] = existingDefault
        profiles[DEFAULT_PROFILE_NAME] = nil
        if db and db.lastProfile == DEFAULT_PROFILE_NAME then
            db.lastProfile = newName
        end
        Print(string.format("Saved profile '%s' was renamed to '%s' because 'Default' is now reserved.", DEFAULT_PROFILE_NAME, newName))
    end

    if type(db.lastProfile) ~= "string" or db.lastProfile == "" then
        db.lastProfile = DEFAULT_PROFILE_NAME
    elseif not IsReservedProfileName(db.lastProfile) then
        local saved = profiles[db.lastProfile]
        if type(saved) ~= "string" or saved == "" then
            db.lastProfile = DEFAULT_PROFILE_NAME
        end
    else
        db.lastProfile = DEFAULT_PROFILE_NAME
    end

    for key, name in pairs(selections) do
        if type(key) ~= "string" or key == "" then
            selections[key] = nil
        elseif type(name) ~= "string" or name == "" or (not IsReservedProfileName(name) and (type(profiles[name]) ~= "string" or profiles[name] == "")) then
            selections[key] = DEFAULT_PROFILE_NAME
        end
    end
end

function addon:ResetNotificationsTab(silent)
    db.showLoot = defaults.showLoot
    db.showQuestItems = defaults.showQuestItems
    db.showLootIcons = defaults.showLootIcons
    db.showLootTotals = defaults.showLootTotals
    db.showUpgradeArrow = defaults.showUpgradeArrow
    db.showMoney = defaults.showMoney
    db.showMoneyIcons = defaults.showMoneyIcons
    db.showCurrency = defaults.showCurrency
    db.showCombat = defaults.showCombat
    db.showHonor = defaults.showHonor
    db.showReputation = defaults.showReputation
    db.showDelveCompanionXP = defaults.showDelveCompanionXP
    db.showSkill = defaults.showSkill

    self:UpdateAnchorVisuals()
    self:SyncActiveProfile()
    self:RefreshConfigUIs()

    if not silent then
        Print("Notifications settings reset.")
    end
end

function addon:ResetLayoutTab(silent)
    db.lootDuration = defaults.lootDuration
    db.scrollDuration = defaults.scrollDuration
    db.fontSize = defaults.fontSize
    db.maxStacked = defaults.maxStacked
    db.maxScrollVisible = defaults.maxScrollVisible
    db.stackPadding = defaults.stackPadding
    db.scrollPadding = defaults.scrollPadding
    db.lootScale = defaults.lootScale
    db.scrollScale = defaults.scrollScale
    db.stackAnchorX = defaults.stackAnchorX
    db.stackAnchorY = defaults.stackAnchorY
    db.scrollAnchorX = defaults.scrollAnchorX
    db.scrollAnchorY = defaults.scrollAnchorY

    if addon.LayoutLootMessages then addon.LayoutLootMessages() end
    self:UpdateAnchorVisuals()
    self:SyncActiveProfile()
    self:RefreshConfigUIs()

    if not silent then
        Print("Layout settings reset.")
    end
end

function addon:ResetColorsTab(silent)
    db.colors = DeepCopy(defaults.colors or {})
    self:UpdateAnchorVisuals()
    self:SyncActiveProfile()
    self:RefreshConfigUIs()

    if not silent then
        Print("Color settings reset.")
    end
end

function addon:ResetCustomizeTab(silent)
    db.combatEnterText = defaults.combatEnterText
    db.combatLeaveText = defaults.combatLeaveText
    db.useIndividualFonts = defaults.useIndividualFonts
    db.stripAutoSymbols = defaults.stripAutoSymbols
    db.globalFont = defaults.globalFont
    db.lootFont = defaults.lootFont
    db.moneyFont = defaults.moneyFont
    db.currencyFont = defaults.currencyFont
    db.combatEnterFont = defaults.combatEnterFont
    db.combatLeaveFont = defaults.combatLeaveFont
    db.honorFont = defaults.honorFont
    db.repGainFont = defaults.repGainFont
    db.repLossFont = defaults.repLossFont
    db.skillFont = defaults.skillFont
    db.hideGreys = defaults.hideGreys

    self:UpdateAnchorVisuals()
    self:SyncActiveProfile()
    self:RefreshConfigUIs()

    if not silent then
        Print("Customize settings reset.")
    end
end

local function GetCurrentCharacterProfileKey()
    if type(currentCharacterKey) == "string" and currentCharacterKey ~= "" then
        return currentCharacterKey
    end

    local name, realm
    if UnitFullName then
        name, realm = UnitFullName("player")
    end
    if not name or name == "" then
        name = UnitName and UnitName("player") or nil
    end
    if not realm or realm == "" then
        realm = GetRealmName and GetRealmName() or ""
    end

    if not name or name == "" then
        return nil
    end

    realm = tostring(realm or ""):gsub("%s+", "")
    currentCharacterKey = (realm ~= "") and (name .. "-" .. realm) or name
    return currentCharacterKey
end

function addon:GetCurrentCharacterProfileKey()
    return GetCurrentCharacterProfileKey()
end

function addon:EnsureCharacterProfilesTable()
    db.characterProfiles = type(db.characterProfiles) == "table" and db.characterProfiles or {}
    return db.characterProfiles
end

function addon:RememberProfileForCurrentCharacter(name)
    if not db then return end
    local key = GetCurrentCharacterProfileKey()
    if not key then return end

    name = tostring(name or "")
    if name == "" then
        name = DEFAULT_PROFILE_NAME
    end

    local selections = self:EnsureCharacterProfilesTable()
    selections[key] = name
end

function addon:GetStoredProfileForCurrentCharacter()
    if not db then
        return DEFAULT_PROFILE_NAME
    end

    local key = GetCurrentCharacterProfileKey()
    if not key then
        return DEFAULT_PROFILE_NAME
    end

    local selections = self:EnsureCharacterProfilesTable()
    local name = selections[key]
    if type(name) ~= "string" or name == "" then
        return DEFAULT_PROFILE_NAME
    end
    if IsReservedProfileName(name) then
        return DEFAULT_PROFILE_NAME
    end

    local profiles = self:EnsureProfilesTable()
    if type(profiles[name]) ~= "string" or profiles[name] == "" then
        return DEFAULT_PROFILE_NAME
    end

    return name
end

function addon:ApplyStoredProfileForCurrentCharacter()
    local name = self:GetStoredProfileForCurrentCharacter()

    if IsReservedProfileName(name) then
        self:ApplyDefaultProfile(true)
        self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
        return true
    end

    local profiles = self:EnsureProfilesTable()
    local text = profiles[name]
    if type(text) ~= "string" or text == "" then
        self:ApplyDefaultProfile(true)
        self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
        return true
    end

    local ok, err = ApplyProfileExportString(text)
    if ok then
        db.lastProfile = name
        self:RememberProfileForCurrentCharacter(name)
        self:RefreshConfigUIs()
        return true
    end

    self:ApplyDefaultProfile(true)
    self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
    return false, err
end

function addon:EnsureProfilesTable()
    db.profiles = type(db.profiles) == "table" and db.profiles or {}
    return db.profiles
end

function addon:SyncActiveProfile(silent)
    if not db then return false end

    local name = db.lastProfile
    if type(name) ~= "string" or name == "" or IsReservedProfileName(name) then
        return false
    end

    local profiles = self:EnsureProfilesTable()
    if type(profiles[name]) ~= "string" or profiles[name] == "" then
        return false
    end

    profiles[name] = GetProfileExportString()

    if silent == false then
        Print(string.format("Profile updated: %s", name))
    end

    return true
end

function addon:SaveProfile(name)
    name = tostring(name or "")
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then
        return false, "Profile name cannot be empty."
    end
    if IsReservedProfileName(name) then
        return false, string.format("'%s' is reserved.", DEFAULT_PROFILE_NAME)
    end
    local profiles = self:EnsureProfilesTable()
    profiles[name] = GetProfileExportString()
    db.lastProfile = name
    self:RememberProfileForCurrentCharacter(name)
    self:RefreshConfigUIs()
    Print(string.format("Profile saved: %s", name))
    return true
end

function addon:SaveImportedProfileAs(name, text)
    name = tostring(name or "")
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then
        return false, "Profile name cannot be empty."
    end
    if IsReservedProfileName(name) then
        return false, string.format("'%s' is reserved.", DEFAULT_PROFILE_NAME)
    end

    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")

    local decoded = DeobfuscateProfileString(text)
    if not decoded then
        return false, "Invalid LootBT profile string."
    end

    local tokens = SplitPipe(decoded)
    if #tokens < 1 or tokens[1] ~= PROFILE_PREFIX then
        return false, "Not a LootBT profile string."
    end

    local profiles = self:EnsureProfilesTable()
    profiles[name] = decoded

    local ok, err = ApplyProfileExportString(decoded)
    if not ok then
        return false, err or "Import failed."
    end

    db.lastProfile = name
    self:RememberProfileForCurrentCharacter(name)
    self:RefreshConfigUIs()
    Print(string.format("Imported profile saved and applied: %s", name))
    return true
end

function addon:DeleteProfile(name)
    if IsReservedProfileName(name) then
        return false, string.format("'%s' cannot be deleted.", DEFAULT_PROFILE_NAME)
    end

    local profiles = self:EnsureProfilesTable()
    local selections = self:EnsureCharacterProfilesTable()
    profiles[name] = nil

    for characterKey, selectedName in pairs(selections) do
        if selectedName == name then
            selections[characterKey] = DEFAULT_PROFILE_NAME
        end
    end

    if db.lastProfile == name then
        db.lastProfile = DEFAULT_PROFILE_NAME
        self:RememberProfileForCurrentCharacter(DEFAULT_PROFILE_NAME)
    end
    self:RefreshConfigUIs()
    Print(string.format("Profile deleted: %s", tostring(name)))
    return true
end

function addon:ApplyProfile(name)
    local current = db and db.lastProfile
    if type(current) == "string" and current ~= "" and not IsReservedProfileName(current) and current ~= name then
        self:SyncActiveProfile()
    end

    if IsReservedProfileName(name) then
        return self:ApplyDefaultProfile()
    end

    local profiles = self:EnsureProfilesTable()
    local text = profiles[name]
    if type(text) ~= "string" or text == "" then
        return false, "That profile is empty or missing."
    end
    local ok, err = ApplyProfileExportString(text)
    if ok then
        db.lastProfile = name
        self:RememberProfileForCurrentCharacter(name)
        self:RefreshConfigUIs()
        Print(string.format("Profile applied: %s", tostring(name)))
    end
    return ok, err
end

function addon:GetSortedProfileNames()
    local profiles = self:EnsureProfilesTable()
    local names = {}
    for name in pairs(profiles) do
        if type(name) == "string" and name ~= "" and not IsReservedProfileName(name) then
            table.insert(names, name)
        end
    end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    return names
end


function addon:ShowExportPopup()
    CloseDropDownMenus()

    local profileName = db and db.lastProfile
    if not db or IsReservedProfileName(profileName) then
        Print("Default profile cannot be exported.")
        return false
    end

    pcall(function() addon:SyncActiveProfile(true) end)

    local plain = GetProfileExportString()
    if type(plain) ~= "string" then
        plain = tostring(plain or "")
    end
    if plain == "" then
        plain = PROFILE_PREFIX
    end

    local exportText = GetProfileExportStringObfuscated()
    addon.pendingExportProfileText = exportText

    if StaticPopup_Show then
        local okShow = pcall(function()
            StaticPopup_Show("LOOTBT_EXPORT_PROFILE_STRING")
        end)
        if okShow then
            return true
        end
    end

    Print(exportText)
    return true
end
function addon:ShowImportPopup()
    CloseDropDownMenus()
    addon.pendingImportDraftText = addon.pendingImportDraftText or ""
    if StaticPopup_Show then
        StaticPopup_Show("LOOTBT_IMPORT_PROFILE_STRING")
        return true
    end
    return false
end

if StaticPopupDialogs and not StaticPopupDialogs["LOOTBT_SAVE_PROFILE"] then
    StaticPopupDialogs["LOOTBT_SAVE_PROFILE"] = {
        text = "Save current LootBT settings as a new profile",
        button1 = "Save",
        button2 = "Cancel",
        hasEditBox = true,
        maxLetters = 64,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
        OnShow = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            if editBox then
                editBox:SetText("")
                editBox:SetFocus()
                editBox:HighlightText()
            end
        end,
        OnAccept = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            local name = editBox and editBox:GetText() or ""
            local ok, err = addon:SaveProfile(name)
            if not ok and err then Print(err) end
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            if parent and parent.button1 and parent.button1:IsEnabled() then
                parent.button1:Click()
            end
        end,
    }
end

if StaticPopupDialogs and not StaticPopupDialogs["LOOTBT_DELETE_PROFILE"] then
    StaticPopupDialogs["LOOTBT_DELETE_PROFILE"] = {
        text = "Delete LootBT profile '%s'?",
        button1 = "Delete",
        button2 = "Cancel",
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
        OnAccept = function(_, data)
            if data then
                addon:DeleteProfile(data)
            end
        end,
    }
end

if StaticPopupDialogs and not StaticPopupDialogs["LOOTBT_IMPORT_PROFILE_NAME"] then
    StaticPopupDialogs["LOOTBT_IMPORT_PROFILE_NAME"] = {
        text = "Save imported LootBT settings as a new profile",
        button1 = "Save & Apply",
        button2 = "Cancel",
        hasEditBox = true,
        maxLetters = 64,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
        OnShow = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            if editBox then
                editBox:SetText("")
                editBox:SetFocus()
                editBox:HighlightText()
            end
        end,
        OnAccept = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            local name = editBox and editBox:GetText() or ""
            local text = addon.pendingImportedProfileText
            addon.pendingImportedProfileText = nil

            local ok, err = addon:SaveImportedProfileAs(name, text)
            if not ok and err then
                Print(err)
            end
        end,
        OnCancel = function()
            addon.pendingImportedProfileText = nil
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            if parent and parent.button1 and parent.button1:IsEnabled() then
                parent.button1:Click()
            end
        end,
    }
end

if StaticPopupDialogs and not StaticPopupDialogs["LOOTBT_EXPORT_PROFILE_STRING"] then
    StaticPopupDialogs["LOOTBT_EXPORT_PROFILE_STRING"] = {
        text = "Ctrl+C to copy your LootBT profile string",
        button1 = "Close",
        hasEditBox = true,
        maxLetters = 0,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
        OnShow = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            local data = tostring(addon.pendingExportProfileText or "")
            if self.SetWidth then
                self:SetWidth(560)
            end
            if editBox then
                if editBox.SetMaxLetters then editBox:SetMaxLetters(0) end
                if editBox.SetWidth then editBox:SetWidth(480) end
                if editBox.EnableMouse then editBox:EnableMouse(true) end
                if editBox.SetAutoFocus then editBox:SetAutoFocus(false) end
                editBox:SetText(data)
                editBox:SetFocus()
                editBox:HighlightText()
                editBox:SetScript("OnMouseUp", function(box)
                    box:SetFocus()
                    box:HighlightText()
                end)
                editBox:SetScript("OnEditFocusGained", function(box)
                    box:HighlightText()
                end)
            end
        end,
        OnHide = function(self)
            addon.pendingExportProfileText = nil
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            if editBox then
                editBox:SetText("")
            end
        end,
        EditBoxOnEscapePressed = function(self)
            local parent = self:GetParent()
            if parent then parent:Hide() end
        end,
        EditBoxOnEnterPressed = function(self)
            self:HighlightText()
        end,
        OnAccept = function(self)
            addon.pendingExportProfileText = nil
            if self and self.Hide then self:Hide() end
        end,
    }
end

if StaticPopupDialogs and not StaticPopupDialogs["LOOTBT_IMPORT_PROFILE_STRING"] then
    StaticPopupDialogs["LOOTBT_IMPORT_PROFILE_STRING"] = {
        text = "Paste a LootBT profile string",
        button1 = "Import",
        button2 = "Cancel",
        hasEditBox = true,
        maxLetters = 0,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
        OnShow = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            if self.SetWidth then
                self:SetWidth(560)
            end
            if editBox then
                if editBox.SetMaxLetters then editBox:SetMaxLetters(0) end
                if editBox.SetWidth then editBox:SetWidth(480) end
                editBox:SetText(tostring(addon.pendingImportDraftText or ""))
                editBox:SetFocus()
                if addon.pendingImportDraftText and addon.pendingImportDraftText ~= "" then
                    editBox:HighlightText()
                end
            end
            addon.pendingImportDraftText = nil
        end,
        OnAccept = function(self)
            local editBox = self.editBox or _G[((self.GetName and self:GetName()) or "") .. "EditBox"]
            local text = editBox and editBox:GetText() or ""
            text = tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")

            local decoded = DeobfuscateProfileString(text)
            if not decoded then
                addon.pendingImportDraftText = text
                Print("Invalid LootBT profile string.")
                if C_Timer and C_Timer.After and StaticPopup_Show then
                    C_Timer.After(0, function() StaticPopup_Show("LOOTBT_IMPORT_PROFILE_STRING") end)
                end
                return
            end

            local tokens = SplitPipe(decoded)
            if #tokens < 1 or tokens[1] ~= PROFILE_PREFIX then
                addon.pendingImportDraftText = text
                Print("Not a LootBT profile string.")
                if C_Timer and C_Timer.After and StaticPopup_Show then
                    C_Timer.After(0, function() StaticPopup_Show("LOOTBT_IMPORT_PROFILE_STRING") end)
                end
                return
            end

            addon.pendingImportedProfileText = text
            if StaticPopup_Show then
                StaticPopup_Show("LOOTBT_IMPORT_PROFILE_NAME")
            else
                local ok, err = addon:SaveImportedProfileAs("Imported", text)
                if not ok then
                    Print(err or "Import failed.")
                end
            end
        end,
        OnCancel = function()
            addon.pendingImportDraftText = nil
        end,
        EditBoxOnEscapePressed = function(self)
            local parent = self:GetParent()
            if parent then parent:Hide() end
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            if parent and parent.button1 and parent.button1:IsEnabled() then
                parent.button1:Click()
            end
        end,
    }
end


U.DEFAULT_PROFILE_NAME = DEFAULT_PROFILE_NAME
U.IsReservedProfileName = IsReservedProfileName
U.GetCurrentCharacterProfileKey = GetCurrentCharacterProfileKey
