local ADDON_NAME, ns = ...
ns = ns or {}

local addon = ns.addon
if not addon then
    addon = CreateFrame("Frame")
    ns.addon = addon
end
_G[ADDON_NAME] = addon

local U = ns.U or {}
ns.U = U

local DEFAULT_COLORS = {
    loot = { 1.00, 1.00, 1.00 },
    money = { 1.00, 0.82, 0.00 },
    currency = { 0.65, 0.85, 1.00 },
    combatEnter = { 1.00, 0.20, 0.20 },
    combatLeave = { 0.30, 1.00, 0.30 },
    honor = { 0.80, 0.55, 1.00 },
    repGain = { 0.20, 0.95, 0.30 },
    repLoss = { 1.00, 0.35, 0.35 },
    skill = { 0.25, 0.80, 1.00 },
}


local DEFAULT_FONT_KEY = "default"
local BASE_FONT_OPTIONS = {
    { key = "default", label = "Default", path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF" },
    { key = "frizqt", label = "Friz Quadrata", path = "Fonts\\FRIZQT__.TTF" },
    { key = "arialn", label = "Arial Narrow", path = "Fonts\\ARIALN.TTF" },
    { key = "morpheus", label = "Morpheus", path = "Fonts\\MORPHEUS.ttf" },
    { key = "skurri", label = "Skurri", path = "Fonts\\skurri.ttf" },
    { key = "blei00d", label = "Blei00d", path = "Fonts\\blei00d.TTF" },
    { key = "2002", label = "2002", path = "Fonts\\2002.TTF" },
    { key = "2002b", label = "2002 Bold", path = "Fonts\\2002B.TTF" },
    { key = "arkai_t", label = "ARKai", path = "Fonts\\ARKai_T.ttf" },
    { key = "arhei", label = "ARHei", path = "Fonts\\ARHei.ttf" },
}
local FONT_OPTIONS = nil
local FONT_INFO_BY_KEY = nil
local BuildFontCatalog
local NormalizeFontKey
local GetMoneyPreviewText
local GetStackMessageStep
local GetScrollMessageStep

local defaults = {
    showLoot = true,
    showQuestItems = true,
    showLootIcons = true,
    showLootTotals = true,
    showUpgradeArrow = false,
    showMoney = true,
    showMoneyIcons = false,
    showCurrency = true,
    showCombat = true,
    combatEnterText = "Entering Combat",
    combatLeaveText = "Leaving Combat",
    showHonor = true,
    showReputation = true,
    showDelveCompanionXP = false,
    showSkill = true,
    hideGreys = false,
    showAnchors = false,
    showMinimap = true,
    lootDuration = 3.50,
    scrollDuration = 5.25,
    fontSize = 22,
    useIndividualFonts = false,
    stripAutoSymbols = false,
    globalFont = DEFAULT_FONT_KEY,
    lootFont = DEFAULT_FONT_KEY,
    moneyFont = DEFAULT_FONT_KEY,
    currencyFont = DEFAULT_FONT_KEY,
    combatEnterFont = DEFAULT_FONT_KEY,
    combatLeaveFont = DEFAULT_FONT_KEY,
    honorFont = DEFAULT_FONT_KEY,
    repGainFont = DEFAULT_FONT_KEY,
    repLossFont = DEFAULT_FONT_KEY,
    skillFont = DEFAULT_FONT_KEY,
    maxStacked = 4,
    maxScrollVisible = 4,
    stackPadding = 2,
    scrollPadding = 4,
    lootScale = 1.00,
    scrollScale = 1.20,
    stackAnchorX = 0,
    stackAnchorY = -160,
    scrollAnchorX = 0,
    scrollAnchorY = -20,
    minimapPos = 220,
    colors = DEFAULT_COLORS,
    minimap = { hide = false, minimapPos = 220 },
    profiles = {},
    characterProfiles = {},
}

local db
local patterns = {}
local backdropTemplate = BackdropTemplateMixin and "BackdropTemplate" or nil

local stackAnchor
local scrollAnchor
local activeLoot = {}
local freeLoot = {}
local activeScroll = {}
local freeScroll = {}
local LayoutActiveScrollMessages
local lootTicker = CreateFrame("Frame")
local pendingStackQueue = {}
local PumpStackQueue
local pendingScrollQueue = {}
local PumpScrollQueue
local scrollQueueArmed = false
local scrollQueueLastShownAt = 0

local predictedItemTotals = {}
local predictedCurrencyTotals = {}
local pendingCurrencyBatches = {}
local pendingReputationBatches = {}
local CURRENCY_BATCH_DELAY = 0.25
local REPUTATION_BATCH_DELAY = 0.40

local minimapButton
local ldbObject
local ldbIcon
local ldbRegistered = false
local function DeepCopy(src)
    if type(src) ~= "table" then
        return src
    end
    local out = {}
    for k, v in pairs(src) do
        out[k] = DeepCopy(v)
    end
    return out
end

local function CopyDefaults(src, dst)
    dst = dst or {}
    for key, value in pairs(src) do
        if type(value) == "table" then
            dst[key] = CopyDefaults(value, type(dst[key]) == "table" and dst[key] or {})
        elseif dst[key] == nil then
            dst[key] = value
        end
    end
    return dst
end

local function Clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function NormalizeColorTable(colors)
    local out = {}
    colors = type(colors) == "table" and colors or {}
    for key, defaultColor in pairs(DEFAULT_COLORS) do
        local current = type(colors[key]) == "table" and colors[key] or defaultColor
        local r = tonumber(current[1]) or defaultColor[1] or 1
        local g = tonumber(current[2]) or defaultColor[2] or 1
        local b = tonumber(current[3]) or defaultColor[3] or 1
        out[key] = { Clamp(r, 0, 1), Clamp(g, 0, 1), Clamp(b, 0, 1) }
    end
    return out
end

local function SanitizeConfigState(state)
    state = type(state) == "table" and state or {}

    local function ensureBoolean(key)
        if type(state[key]) ~= "boolean" then
            state[key] = defaults[key] and true or false
        end
    end

    local function ensureNumber(key, fallback, lo, hi, whole)
        local value = tonumber(state[key])
        if value == nil then
            value = fallback
        end
        if lo ~= nil and hi ~= nil then
            value = Clamp(value, lo, hi)
        end
        if whole then
            value = math.floor(value + 0.5)
        end
        state[key] = value
    end

    local function ensureString(key)
        if type(state[key]) ~= "string" or state[key] == "" then
            state[key] = defaults[key] or ""
        end
    end

    ensureBoolean("showLoot")
    ensureBoolean("showQuestItems")
    ensureBoolean("showLootIcons")
    ensureBoolean("showLootTotals")
    ensureBoolean("showUpgradeArrow")
    ensureBoolean("showMoney")
    ensureBoolean("showMoneyIcons")
    ensureBoolean("showCurrency")
    ensureBoolean("showCombat")
    ensureBoolean("showHonor")
    ensureBoolean("showReputation")
    ensureBoolean("showDelveCompanionXP")
    ensureBoolean("showSkill")
    ensureBoolean("hideGreys")
    ensureBoolean("showAnchors")
    ensureBoolean("showMinimap")
    ensureBoolean("useIndividualFonts")
    ensureBoolean("stripAutoSymbols")

    ensureNumber("lootDuration", defaults.lootDuration, 1.0, 8.0)
    ensureNumber("scrollDuration", defaults.scrollDuration, 2.0, 8.0)
    ensureNumber("fontSize", defaults.fontSize, 14, 36, true)
    ensureNumber("maxStacked", defaults.maxStacked, 1, 12, true)
    ensureNumber("maxScrollVisible", defaults.maxScrollVisible, 1, 12, true)
    ensureNumber("stackPadding", defaults.stackPadding, -50, 40, true)
    ensureNumber("scrollPadding", defaults.scrollPadding, -50, 40, true)
    ensureNumber("lootScale", defaults.lootScale, 0.6, 2.0)
    ensureNumber("scrollScale", defaults.scrollScale, 0.6, 2.0)
    ensureNumber("stackAnchorX", defaults.stackAnchorX, -5000, 5000, true)
    ensureNumber("stackAnchorY", defaults.stackAnchorY, -5000, 5000, true)
    ensureNumber("scrollAnchorX", defaults.scrollAnchorX, -5000, 5000, true)
    ensureNumber("scrollAnchorY", defaults.scrollAnchorY, -5000, 5000, true)
    ensureNumber("minimapPos", defaults.minimapPos, -360, 360)

    ensureString("combatEnterText")
    ensureString("combatLeaveText")
    ensureString("globalFont")
    ensureString("lootFont")
    ensureString("moneyFont")
    ensureString("currencyFont")
    ensureString("combatEnterFont")
    ensureString("combatLeaveFont")
    ensureString("honorFont")
    ensureString("repGainFont")
    ensureString("repLossFont")
    ensureString("skillFont")

    state.colors = NormalizeColorTable(state.colors)

    state.globalFont = NormalizeFontKey(state.globalFont)
    state.lootFont = NormalizeFontKey(state.lootFont)
    state.moneyFont = NormalizeFontKey(state.moneyFont)
    state.currencyFont = NormalizeFontKey(state.currencyFont)
    state.combatEnterFont = NormalizeFontKey(state.combatEnterFont)
    state.combatLeaveFont = NormalizeFontKey(state.combatLeaveFont)
    state.honorFont = NormalizeFontKey(state.honorFont)
    state.repGainFont = NormalizeFontKey(state.repGainFont)
    state.repLossFont = NormalizeFontKey(state.repLossFont)
    state.skillFont = NormalizeFontKey(state.skillFont)

    state.minimap = type(state.minimap) == "table" and state.minimap or {}
    if type(state.minimap.hide) ~= "boolean" then
        state.minimap.hide = not state.showMinimap
    end
    state.minimap.minimapPos = tonumber(state.minimap.minimapPos)
    if state.minimap.minimapPos == nil then
        state.minimap.minimapPos = state.minimapPos
    else
        state.minimap.minimapPos = Clamp(state.minimap.minimapPos, -360, 360)
    end
    state.minimapPos = Clamp(tonumber(state.minimapPos) or state.minimap.minimapPos or defaults.minimapPos, -360, 360)

    state.profiles = type(state.profiles) == "table" and state.profiles or {}
    for key, value in pairs(state.profiles) do
        if type(key) ~= "string" or key == "" or type(value) ~= "string" or value == "" then
            state.profiles[key] = nil
        end
    end

    state.characterProfiles = type(state.characterProfiles) == "table" and state.characterProfiles or {}
    for key, value in pairs(state.characterProfiles) do
        if type(key) ~= "string" or key == "" or type(value) ~= "string" or value == "" then
            state.characterProfiles[key] = nil
        end
    end

    state.taskObjectiveCache = type(state.taskObjectiveCache) == "table" and state.taskObjectiveCache or {}

    return state
end

local function SanitizeRuntimeConfig()
    if not db then return end
    SanitizeConfigState(db)
end

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99LootBT:|r " .. tostring(msg))
    end
end

local function ParseNumeric(text)
    if not text then return 0 end
    text = tostring(text):gsub(",", "")
    return tonumber(text) or 0
end

local function FormatNumber(n)
    n = tonumber(n) or 0
    if BreakUpLargeNumbers then
        return BreakUpLargeNumbers(n)
    end
    local neg = n < 0 and "-" or ""
    n = math.abs(math.floor(n + 0.5))
    local s = tostring(n)
    while true do
        local new, count = s:gsub("^(%d+)(%d%d%d)", "%1,%2")
        s = new
        if count == 0 then break end
    end
    return neg .. s
end

local function StripColorCodes(text)
    text = tostring(text or "")
    text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
    text = text:gsub("|r", "")
    return text
end

local function ExtractBracketName(text)
    text = tostring(text or "")
    local name = text:match("|h%[(.-)%]|h")
    if name then return name end
    return StripColorCodes(text)
end

BuildFontCatalog = function(force)
    if force then
        FONT_OPTIONS = nil
        FONT_INFO_BY_KEY = nil
    end
    if FONT_OPTIONS and FONT_INFO_BY_KEY then
        return FONT_OPTIONS, FONT_INFO_BY_KEY
    end

    local options = {}
    local byKey = {}

    local function add(key, label, path)
        key = tostring(key or "")
        label = tostring(label or key)
        path = tostring(path or "")
        if key == "" or path == "" or byKey[key] then
            return
        end
        local entry = { key = key, label = label, path = path }
        options[#options + 1] = entry
        byKey[key] = entry
    end

    for _, entry in ipairs(BASE_FONT_OPTIONS) do
        add(entry.key, entry.label, entry.path)
    end

    local extraFontObjects = {
        { key = "chatfont", label = "Chat Font", object = _G.ChatFontNormal },
        { key = "gamefont", label = "Game Font", object = _G.GameFontNormal },
        { key = "questfont", label = "Quest Font", object = _G.QuestFont },
        { key = "numberfont", label = "Number Font", object = _G.NumberFontNormal },
        { key = "damagefont", label = "Damage Font", object = _G.DamageTextFont },
    }
    for _, entry in ipairs(extraFontObjects) do
        local fontObject = entry.object
        if fontObject and fontObject.GetFont then
            local ok, path = pcall(fontObject.GetFont, fontObject)
            if ok and type(path) == "string" and path ~= "" then
                add(entry.key, entry.label, path)
            end
        end
    end

    if LibStub then
        local ok, LSM = pcall(function() return LibStub("LibSharedMedia-3.0", true) end)
        if ok and LSM and LSM.HashTable then
            local hash = LSM:HashTable("font")
            if type(hash) == "table" then
                local names = {}
                for name in pairs(hash) do
                    names[#names + 1] = name
                end
                table.sort(names, function(a, b)
                    return tostring(a):lower() < tostring(b):lower()
                end)
                for _, name in ipairs(names) do
                    local path = hash[name]
                    add("lsm:" .. tostring(name), tostring(name) .. " (LSM)", path)
                end
            end
        end
    end

    FONT_OPTIONS = options
    FONT_INFO_BY_KEY = byKey
    return options, byKey
end

NormalizeFontKey = function(key)
    BuildFontCatalog()
    key = tostring(key or "")
    if FONT_INFO_BY_KEY[key] then
        return key
    end
    return DEFAULT_FONT_KEY
end

local function GetFontRoleSettingKey(role)
    if type(role) ~= "string" or role == "" then
        return nil
    end
    return role .. "Font"
end

local function GetConfiguredFontKeyForRole(role)
    local fallback = defaults.globalFont or DEFAULT_FONT_KEY
    if not db then
        return fallback
    end

    if db.useIndividualFonts then
        local settingKey = GetFontRoleSettingKey(role)
        if settingKey then
            local value = db[settingKey]
            if type(value) == "string" and value ~= "" then
                return NormalizeFontKey(value)
            end
        end
    end

    return NormalizeFontKey(db.globalFont or fallback)
end

local function GetFontInfoForRole(role)
    BuildFontCatalog()
    local key = GetConfiguredFontKeyForRole(role)
    return FONT_INFO_BY_KEY[key] or FONT_INFO_BY_KEY[DEFAULT_FONT_KEY]
end

local function GetFontLabelByKey(key)
    BuildFontCatalog()
    local info = FONT_INFO_BY_KEY[NormalizeFontKey(key)] or FONT_INFO_BY_KEY[DEFAULT_FONT_KEY]
    return (info and info.label) or "Default"
end

local function ShouldUseSimpleAutoSymbols(role)
    return db and db.stripAutoSymbols or false
end

local function StripAutoBracketsFromLinkText(text)
    text = tostring(text or "")
    text = text:gsub("(|h)%[(.-)%](|h)", "%1%2%3")
    return text
end

local LOOT_ITEM_ICON_SIZE = 14
local LOOT_PREVIEW_ITEM_ID = 50818
local LOOT_PREVIEW_ITEM_LINK = "|cffa335ee|Hitem:50818::::::::1:::::::|h[Invincible's Reins]|h|r"

local function GetLootDisplayItemText(itemText)
    if ShouldUseSimpleAutoSymbols("loot") then
        return StripAutoBracketsFromLinkText(itemText)
    end
    return itemText
end

local function GetLootItemIconPrefix(itemQuery)
    if not db or not db.showLootIcons then
        return ""
    end

    local icon
    if C_Item and C_Item.GetItemInfoInstant then
        local _, _, _, _, texture = C_Item.GetItemInfoInstant(itemQuery)
        icon = texture
    elseif GetItemInfoInstant then
        local _, _, _, _, texture = GetItemInfoInstant(itemQuery)
        icon = texture
    end

    if not icon and C_Item and C_Item.GetItemIconByID and type(itemQuery) == "number" then
        icon = C_Item.GetItemIconByID(itemQuery)
    end

    if not icon and GetItemIcon then
        local ok, texture = pcall(GetItemIcon, itemQuery)
        if ok then
            icon = texture
        end
    end

    if not icon then
        return ""
    end

    return "|T" .. tostring(icon) .. ":" .. LOOT_ITEM_ICON_SIZE .. ":" .. LOOT_ITEM_ICON_SIZE .. ":0:0|t "
end

local function FormatLootDisplaySuffix(total, required)
    if not db or db.showLootTotals == false then
        return ""
    end

    if required and required > 0 then
        local fulfilled = math.min(required, tonumber(total) or 0)
        return string.format(" (%d/%d)", fulfilled, required)
    end

    if total ~= nil then
        return string.format(" (%s)", FormatNumber(total))
    end

    return ""
end

local function GetLootPreviewText()
    local displayItemText = GetLootDisplayItemText(LOOT_PREVIEW_ITEM_LINK)
    local iconPrefix = GetLootItemIconPrefix(LOOT_PREVIEW_ITEM_ID)
    local suffix = FormatLootDisplaySuffix(1)
    return string.format("1x %s%s%s", iconPrefix, displayItemText, suffix)
end

local function FormatCurrencyDisplayText(name, amount, total)
    name = tostring(name or "Currency")
    amount = tonumber(amount) or 0
    local suffix = total ~= nil and string.format(" (%s)", FormatNumber(total)) or ""
    if ShouldUseSimpleAutoSymbols("currency") then
        return string.format("%s %s%s", FormatNumber(amount), name, suffix)
    end
    return string.format("+%s %s%s", FormatNumber(amount), name, suffix)
end

local function FormatHonorDisplayText(amount)
    amount = tonumber(amount) or 0
    if ShouldUseSimpleAutoSymbols("honor") then
        return string.format("%s Honor", FormatNumber(amount))
    end
    return string.format("+%s Honor", FormatNumber(amount))
end

local function FormatReputationDisplayText(text, isLoss)
    text = tostring(text or "")
    if not ShouldUseSimpleAutoSymbols(isLoss and "repLoss" or "repGain") then
        return text
    end
    if isLoss then
        text = text:gsub(" Rep %-", " Rep loss ")
        text = text:gsub("%-(%d)", "%1")
        return text
    end
    text = text:gsub(" Rep %+", " Rep ")
    text = text:gsub("%+(%d)", "%1")
    return text
end

local function SetMessageFont(fs, scale, role)
    if not fs then return end
    local size = math.max(8, ((db and db.fontSize) or defaults.fontSize) * (scale or 1))
    local info = role and GetFontInfoForRole(role) or nil
    local fontPath = (info and info.path) or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    local ok = fs:SetFont(fontPath, size, "OUTLINE")
    if not ok and fontPath ~= (STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF") then
        fs:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", size, "OUTLINE")
    end
    fs:SetShadowOffset(1, -1)
    fs:SetShadowColor(0, 0, 0, 1)
end

local function SetAnchorTitleFont(fs)
    if not fs then return end
    local fontPath = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    fs:SetFont(fontPath, 13, "")
    fs:SetShadowOffset(1, -1)
    fs:SetShadowColor(0, 0, 0, 1)
end

local function GetColorForKey(key)
    local color = db and db.colors and db.colors[key]
    if not color then
        color = DEFAULT_COLORS[key] or { 1, 1, 1 }
    end
    return color[1] or 1, color[2] or 1, color[3] or 1
end

local function SetColorForKey(key, r, g, b)
    db.colors = db.colors or {}
    db.colors[key] = { tonumber(r) or 1, tonumber(g) or 1, tonumber(b) or 1 }
end

local function GetCombatEnterText()
    local text = db and db.combatEnterText
    if type(text) ~= "string" or text == "" then
        return defaults.combatEnterText
    end
    return text
end

local function GetCombatLeaveText()
    local text = db and db.combatLeaveText
    if type(text) ~= "string" or text == "" then
        return defaults.combatLeaveText
    end
    return text
end

local function EscapeLuaPattern(text)
    if not text then return nil end
    return (text:gsub("([%(%)%.%%%+%-%*%?%[%^%$])", "%%%1"))
end

local function BuildPattern(globalString)
    if not globalString or globalString == "" then return nil end
    local pattern = EscapeLuaPattern(globalString)
    pattern = pattern:gsub("%%%%%d+%$s", "(.+)")
    pattern = pattern:gsub("%%%%%d+%$d", "(%%d+)")
    pattern = pattern:gsub("%%%%s", "(.+)")
    pattern = pattern:gsub("%%%%d", "(%%d+)")
    return "^" .. pattern .. "$"
end

local function BuildAmountPattern(globalString)
    if not globalString or globalString == "" then return nil end
    local pattern = EscapeLuaPattern(globalString)
    pattern = pattern:gsub("%%%%%d+%$d", "(%%d+)")
    pattern = pattern:gsub("%%%%d", "(%%d+)")
    return pattern
end

local function RebuildPatterns()
    patterns.lootSelf = BuildPattern(LOOT_ITEM_SELF)
    patterns.lootSelfMultiple = BuildPattern(LOOT_ITEM_SELF_MULTIPLE)
    patterns.lootPushedSelf = BuildPattern(LOOT_ITEM_PUSHED_SELF)
    patterns.lootPushedSelfMultiple = BuildPattern(LOOT_ITEM_PUSHED_SELF_MULTIPLE)
    patterns.lootBonusSelf = BuildPattern(LOOT_ITEM_BONUS_ROLL_SELF)
    patterns.lootBonusSelfMultiple = BuildPattern(LOOT_ITEM_BONUS_ROLL_SELF_MULTIPLE)
    patterns.lootCreatedSelf = BuildPattern(LOOT_ITEM_CREATED_SELF)
    patterns.lootCreatedSelfMultiple = BuildPattern(LOOT_ITEM_CREATED_SELF_MULTIPLE)

    patterns.moneyYou = BuildPattern(YOU_LOOT_MONEY)
    patterns.moneyYouGuild = BuildPattern(YOU_LOOT_MONEY_GUILD)
    patterns.moneySplit = BuildPattern(LOOT_MONEY_SPLIT)
    patterns.moneySplitGuild = BuildPattern(LOOT_MONEY_SPLIT_GUILD)
    patterns.goldAmount = BuildAmountPattern(GOLD_AMOUNT)
    patterns.silverAmount = BuildAmountPattern(SILVER_AMOUNT)
    patterns.copperAmount = BuildAmountPattern(COPPER_AMOUNT)

    patterns.currencySingle = BuildPattern(CURRENCY_GAINED)
    patterns.currencyMultiple = BuildPattern(CURRENCY_GAINED_MULTIPLE)
    patterns.currencySingleBonus = BuildPattern(CURRENCY_GAINED_BONUS)
    patterns.currencyMultipleBonus = BuildPattern(CURRENCY_GAINED_MULTIPLE_BONUS)
end

local function CreateBackdrop(frame)
    if not frame or not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 14,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
end

local function GetItemKeyAndQuery(itemText)
    if not itemText then return nil, nil end
    local itemID = itemText:match("|Hitem:(%d+):")
    if itemID then
        itemID = tonumber(itemID)
        return "item:" .. itemID, itemID
    end
    local token = itemText:match("|Hitem:[^|]+|h")
    if token then
        return token, token
    end
    return nil, nil
end

local function GetActualItemCount(query)
    if not query then return 0 end
    local ok, count = pcall(function() return GetItemCount(query, true) end)
    if ok and count then
        return tonumber(count) or 0
    end
    return 0
end

local function GetCurrencyIDAndName(currencyText)
    if not currencyText then return nil, nil end
    local currencyID = currencyText:match("|Hcurrency:(%d+)")
    if currencyID then
        currencyID = tonumber(currencyID)
    end
    return currencyID, ExtractBracketName(currencyText)
end

local function GetActualCurrencyCount(currencyID)
    if not currencyID then return nil end
    if C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo then
        local info = C_CurrencyInfo.GetCurrencyInfo(currencyID)
        if info and info.quantity ~= nil then
            return tonumber(info.quantity) or 0
        end
    end
    if GetCurrencyInfo then
        local name, amount = GetCurrencyInfo(currencyID)
        if name ~= nil and amount ~= nil then
            return tonumber(amount) or 0
        end
    end
    return nil
end

local function GetAnchorPreviewLineHeight(scale)
    local base = ((db and db.fontSize) or defaults.fontSize) * (scale or 1)
    return math.max(base + 4, 16)
end

local function LayoutAnchorPreviewLines(frame, previews, scale, step)
    local count = #previews
    local height = 46 + (math.max(count - 1, 0) * step) + GetAnchorPreviewLineHeight(scale)

    frame:SetHeight(math.max(height, 86))

    for index, preview in ipairs(previews) do
        local fs = preview.fs
        fs:ClearAllPoints()
        fs:SetPoint("TOP", frame, "TOP", 0, -30 - ((index - 1) * step))
        fs:SetJustifyH("CENTER")
        fs:SetText(preview.text or "")
        SetMessageFont(fs, scale, preview.role or preview.colorKey)
        do
            local r, g, b = GetColorForKey(preview.colorKey)
            fs:SetTextColor(r, g, b)
        end
        fs:Show()
    end

    for index = count + 1, #(frame.previews or {}) do
        frame.previews[index]:Hide()
    end
end

local function EnsureAnchors()
    if stackAnchor and scrollAnchor then return end

    stackAnchor = CreateFrame("Frame", ADDON_NAME .. "StackAnchor", UIParent, backdropTemplate)
    stackAnchor:SetSize(420, 118)
    stackAnchor:SetFrameStrata("DIALOG")
    CreateBackdrop(stackAnchor)

    scrollAnchor = CreateFrame("Frame", ADDON_NAME .. "ScrollAnchor", UIParent, backdropTemplate)
    scrollAnchor:SetSize(420, 118)
    scrollAnchor:SetFrameStrata("DIALOG")
    CreateBackdrop(scrollAnchor)

    local function setupAnchor(frame, title)
        frame:SetMovable(true)
        frame:SetClampedToScreen(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", function(self)
            if db and db.showAnchors and not InCombatLockdown() then
                self:StartMoving()
            end
        end)
        frame:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            local cx, cy = self:GetCenter()
            local ux, uy = UIParent:GetCenter()
            if cx and cy and ux and uy then
                if self == stackAnchor then
                    db.stackAnchorX = math.floor(cx - ux + 0.5)
                    db.stackAnchorY = math.floor(cy - uy + 0.5)
                else
                    db.scrollAnchorX = math.floor(cx - ux + 0.5)
                    db.scrollAnchorY = math.floor(cy - uy + 0.5)
                end
            end
            addon:SyncActiveProfile()
            addon:RefreshConfigUIs()
        end)

        frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        frame.title:SetPoint("TOPLEFT", 10, -9)
        frame.title:SetText(title)

        frame.lockButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        frame.lockButton:SetSize(44, 20)
        frame.lockButton:SetPoint("TOPRIGHT", -8, -7)
        frame.lockButton:SetText("Lock")
        frame.lockButton:SetScript("OnClick", function()
            db.showAnchors = false
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end)

        frame.previews = {}
        for index = 1, 3 do
            local fs = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            fs:SetJustifyH("CENTER")
            frame.previews[index] = fs
        end
    end

    setupAnchor(stackAnchor, "Stack Anchor")
    setupAnchor(scrollAnchor, "Scroll Anchor")
end

function addon:UpdateAnchorVisuals()
    EnsureAnchors()
    stackAnchor:ClearAllPoints()
    stackAnchor:SetPoint("CENTER", UIParent, "CENTER", db.stackAnchorX or defaults.stackAnchorX, db.stackAnchorY or defaults.stackAnchorY)
    scrollAnchor:ClearAllPoints()
    scrollAnchor:SetPoint("CENTER", UIParent, "CENTER", db.scrollAnchorX or defaults.scrollAnchorX, db.scrollAnchorY or defaults.scrollAnchorY)

    local shown = db.showAnchors and not InCombatLockdown()
    stackAnchor:SetShown(shown)
    scrollAnchor:SetShown(shown)
    stackAnchor:EnableMouse(shown)
    scrollAnchor:EnableMouse(shown)

    local function styleAnchor(frame, previews, scale, step)
        if shown then
            if frame.SetBackdropColor then
                frame:SetBackdropColor(0.06, 0.08, 0.10, 0.78)
                frame:SetBackdropBorderColor(0.30, 0.90, 0.65, 0.95)
            end
            frame.title:Show()
            frame.lockButton:Show()
            LayoutAnchorPreviewLines(frame, previews, scale, step)
        else
            if frame.SetBackdropColor then
                frame:SetBackdropColor(0, 0, 0, 0)
                frame:SetBackdropBorderColor(0, 0, 0, 0)
            end
            frame.title:Hide()
            frame.lockButton:Hide()
            for _, fs in ipairs(frame.previews or {}) do
                fs:Hide()
            end
        end
        SetAnchorTitleFont(frame.title)
    end

    local stackPreviewItem = GetLootPreviewText()
    local stackPreviewMoney = GetMoneyPreviewText()
    local stackPreviewCurrency = FormatCurrencyDisplayText("Valorstones", 5, 1245)
    local scrollPreviewCombat = GetCombatEnterText()
    local scrollPreviewRep = FormatReputationDisplayText("Guild Rep +125", false)
    local scrollPreviewSkill = "Midnight Leatherworking 40"

    styleAnchor(stackAnchor, {
        { fs = stackAnchor.previews[1], text = stackPreviewItem, colorKey = "loot", role = "loot" },
        { fs = stackAnchor.previews[2], text = stackPreviewMoney, colorKey = "money", role = "money" },
        { fs = stackAnchor.previews[3], text = stackPreviewCurrency, colorKey = "currency", role = "currency" },
    }, db.lootScale, GetStackMessageStep())

    styleAnchor(scrollAnchor, {
        { fs = scrollAnchor.previews[1], text = scrollPreviewCombat, colorKey = "combatEnter", role = "combatEnter" },
        { fs = scrollAnchor.previews[2], text = scrollPreviewRep, colorKey = "repGain", role = "repGain" },
        { fs = scrollAnchor.previews[3], text = scrollPreviewSkill, colorKey = "skill", role = "skill" },
    }, db.scrollScale, GetScrollMessageStep())
end

function addon.SetAnchorUnlockState(unlocked)
    if not db then return end
    unlocked = unlocked and true or false
    if unlocked and InCombatLockdown() then
        Print("Anchors cannot be unlocked in combat.")
        db.showAnchors = false
    else
        db.showAnchors = unlocked
    end
    addon:UpdateAnchorVisuals()
    addon:SyncActiveProfile()
    addon:RefreshConfigUIs()
end


local function RemoveActiveScroll(frame)
    for i = #activeScroll, 1, -1 do
        if activeScroll[i] == frame then
            table.remove(activeScroll, i)
            break
        end
    end
    if #activeScroll > 0 then
        LayoutActiveScrollMessages()
    end
    if PumpScrollQueue then
        PumpScrollQueue()
    end
end

local function GetScrollCategory(colorKey, category)
    if type(category) == "string" and category ~= "" then
        return category
    end
    if colorKey == "combatEnter" or colorKey == "combatLeave" then
        return "combat"
    end
    return nil
end

local function ReleaseScrollFrame(frame)
    if not frame or frame._lootbtReleasing then return end
    frame._lootbtReleasing = true
    if frame.anim then
        frame.anim:Stop()
    end
    RemoveActiveScroll(frame)
    frame:Hide()
    frame:SetAlpha(1)
    frame:SetScale(1)
    frame.baseOffsetY = nil
    frame.scrollCategory = nil
    frame.fontRole = nil
    frame._lootbtReleasing = nil
    table.insert(freeScroll, frame)
end

local function ClearPendingScrollCategory(category)
    if not category then return end
    for i = #pendingScrollQueue, 1, -1 do
        local entry = pendingScrollQueue[i]
        if entry and entry.category == category then
            table.remove(pendingScrollQueue, i)
        end
    end
end

local function ClearActiveScrollCategory(category)
    if not category then return end
    for i = #activeScroll, 1, -1 do
        local frame = activeScroll[i]
        if frame and frame.scrollCategory == category then
            ReleaseScrollFrame(frame)
        end
    end
end

local function AcquireLootFrame()
    local frame = table.remove(freeLoot)
    if frame then
        frame:SetAlpha(1)
        frame:SetScale(1)
        return frame
    end
    frame = CreateFrame("Frame", nil, UIParent)
    frame:SetFrameStrata("HIGH")
    frame:SetSize(560, ((db and db.fontSize) or defaults.fontSize) + 8)
    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.text:SetPoint("CENTER")
    frame.text:SetJustifyH("CENTER")
    SetMessageFont(frame.text)
    return frame
end

GetStackMessageStep = function()
    local scale = (db and db.lootScale) or defaults.lootScale
    local padding = (db and db.stackPadding) or defaults.stackPadding or 0
    local base = ((db and db.fontSize) or defaults.fontSize) + 4
    return math.max((base * scale) + padding, 8)
end

GetScrollMessageStep = function()
    local scale = (db and db.scrollScale) or defaults.scrollScale
    local padding = (db and db.scrollPadding) or defaults.scrollPadding or 0
    local base = ((db and db.fontSize) or defaults.fontSize) + 4
    return math.max((base * scale) + padding, 8)
end

local function GetScrollTravelDistance()
    return math.max(GetScrollMessageStep() + 12, 46)
end

local function GetScrollQueueDelay()
    local step = GetScrollMessageStep()
    return Clamp(step / 140, 0.16, 0.32)
end

local function LayoutLootMessages()
    local scale = db.lootScale or defaults.lootScale
    local step = GetStackMessageStep()
    for i, frame in ipairs(activeLoot) do
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", stackAnchor, "CENTER", 0, (i - 1) * step)
        frame:SetScale(scale)
        SetMessageFont(frame.text, 1, frame.fontRole)
    end
end

local function StartLootTicker()
    if lootTicker:GetScript("OnUpdate") then return end
    lootTicker:SetScript("OnUpdate", function()
        local now = GetTime()
        local changed = false
        for i = #activeLoot, 1, -1 do
            local frame = activeLoot[i]
            local remaining = (frame.expireAt or 0) - now
            if remaining <= 0 then
                frame:Hide()
                frame:SetAlpha(1)
                frame:SetScale(1)
                frame.fontRole = nil
                table.remove(activeLoot, i)
                table.insert(freeLoot, frame)
                changed = true
            elseif remaining < 0.40 then
                frame:SetAlpha(remaining / 0.40)
            else
                frame:SetAlpha(1)
            end
        end
        if changed then
            LayoutLootMessages()
            if PumpStackQueue then
                PumpStackQueue()
            end
        end
        if #activeLoot == 0 then
            lootTicker:SetScript("OnUpdate", nil)
        end
    end)
end

local function ShowCenterTextNow(text, colorKey, fontRole)
    EnsureAnchors()
    local frame = AcquireLootFrame()
    local r, g, b = GetColorForKey(colorKey)
    frame.fontRole = fontRole or colorKey
    frame.text:SetText(text)
    frame.text:SetTextColor(r, g, b)
    frame.expireAt = GetTime() + (db.lootDuration or defaults.lootDuration)
    frame:Show()
    table.insert(activeLoot, 1, frame)
    LayoutLootMessages()
    StartLootTicker()
end

PumpStackQueue = function()
    local maxVisible = math.max(1, (db and db.maxStacked) or defaults.maxStacked or 4)
    while #pendingStackQueue > 0 and #activeLoot < maxVisible do
        local nextEntry = table.remove(pendingStackQueue, 1)
        ShowCenterTextNow(nextEntry.text, nextEntry.colorKey, nextEntry.fontRole)
    end
end

local function ShowCenterText(text, colorKey, fontRole)
    if not text or text == "" then return end

    local maxVisible = math.max(1, (db and db.maxStacked) or defaults.maxStacked or 4)
    if #activeLoot >= maxVisible then
        pendingStackQueue[#pendingStackQueue + 1] = {
            text = text,
            colorKey = colorKey,
            fontRole = fontRole or colorKey,
        }
        return
    end

    ShowCenterTextNow(text, colorKey, fontRole)
end

local function RefreshScrollAnimation(frame)
    local duration = db.scrollDuration or defaults.scrollDuration
    local distance = GetScrollTravelDistance()
    frame.move:SetOffset(0, distance)
    frame.move:SetDuration(duration)
    frame.move:SetSmoothing("IN_OUT")
    frame.fade:SetStartDelay(duration * 0.72)
    frame.fade:SetDuration(duration * 0.28)
end

local function AcquireScrollFrame()
    local frame = table.remove(freeScroll)
    if frame then
        frame:SetAlpha(1)
        frame:SetScale(1)
        RefreshScrollAnimation(frame)
        return frame
    end
    frame = CreateFrame("Frame", nil, UIParent)
    frame:SetFrameStrata("HIGH")
    frame:SetSize(620, ((db and db.fontSize) or defaults.fontSize) + 12)
    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.text:SetPoint("CENTER")
    frame.text:SetJustifyH("CENTER")
    SetMessageFont(frame.text)

    frame.anim = frame:CreateAnimationGroup()
    frame.move = frame.anim:CreateAnimation("Translation")
    frame.fade = frame.anim:CreateAnimation("Alpha")
    frame.fade:SetFromAlpha(1)
    frame.fade:SetToAlpha(0)
    frame.anim:SetScript("OnFinished", function(group)
        local owner = group:GetParent()
        if owner._lootbtReleasing then
            return
        end
        RemoveActiveScroll(owner)
        owner:Hide()
        owner:SetAlpha(1)
        owner:SetScale(1)
        owner.baseOffsetY = nil
        owner.scrollCategory = nil
        owner.fontRole = nil
        table.insert(freeScroll, owner)
    end)
    RefreshScrollAnimation(frame)
    return frame
end

local function GetScrollFrameStep()
    return GetScrollMessageStep()
end

LayoutActiveScrollMessages = function()
    local offsetY = 0
    local step = GetScrollFrameStep()
    for _, frame in ipairs(activeScroll) do
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", scrollAnchor, "CENTER", 0, offsetY)
        offsetY = offsetY - step
    end
end

local function ShowScrollTextNow(text, colorKey, category, fontRole)
    if not text or text == "" then return end
    EnsureAnchors()
    local frame = AcquireScrollFrame()
    if frame.anim then frame.anim:Stop() end
    RefreshScrollAnimation(frame)
    local scale = db.scrollScale or defaults.scrollScale
    frame:SetScale(scale)
    frame.scrollCategory = GetScrollCategory(colorKey, category)
    frame.fontRole = fontRole or colorKey
    SetMessageFont(frame.text, 1, frame.fontRole)
    do
        local r, g, b = GetColorForKey(colorKey)
        frame.text:SetTextColor(r, g, b)
    end
    frame.text:SetText(text)
    frame:SetAlpha(1)
    frame:Show()
    table.insert(activeScroll, 1, frame)
    LayoutActiveScrollMessages()
    frame.anim:Play()
end

PumpScrollQueue = function()
    scrollQueueArmed = false
    if #pendingScrollQueue == 0 then return end

    local maxVisible = math.max(1, (db and db.maxScrollVisible) or defaults.maxScrollVisible or 4)
    if #activeScroll >= maxVisible then
        return
    end

    local now = GetTime()
    local queueDelay = GetScrollQueueDelay()
    local readyAt = (scrollQueueLastShownAt or 0) + queueDelay
    if now < readyAt and C_Timer and C_Timer.After then
        scrollQueueArmed = true
        C_Timer.After(readyAt - now, PumpScrollQueue)
        return
    end

    local nextEntry = table.remove(pendingScrollQueue, 1)
    if nextEntry then
        scrollQueueLastShownAt = now
        ShowScrollTextNow(nextEntry.text, nextEntry.colorKey, nextEntry.category, nextEntry.fontRole)
    end

    if #pendingScrollQueue > 0 and #activeScroll < maxVisible and C_Timer and C_Timer.After then
        scrollQueueArmed = true
        C_Timer.After(GetScrollQueueDelay(), PumpScrollQueue)
    end
end

local function ShowScrollText(text, colorKey, category, fontRole)
    if not text or text == "" then return end

    category = GetScrollCategory(colorKey, category)
    if category == "combat" then
        ClearPendingScrollCategory(category)
        ClearActiveScrollCategory(category)
    end

    if not (C_Timer and C_Timer.After) then
        ShowScrollTextNow(text, colorKey, category, fontRole)
        return
    end

    pendingScrollQueue[#pendingScrollQueue + 1] = {
        text = text,
        colorKey = colorKey,
        category = category,
        fontRole = fontRole or colorKey,
    }

    if not scrollQueueArmed then
        PumpScrollQueue()
    end
end

local function ParseLootMessage(msg)
    if not msg then return nil end
    local item, count
    local ordered = {
        "lootSelfMultiple", "lootPushedSelfMultiple", "lootBonusSelfMultiple", "lootCreatedSelfMultiple",
    }
    for _, key in ipairs(ordered) do
        if patterns[key] then
            item, count = msg:match(patterns[key])
            if item then return item, tonumber(count) or 1 end
        end
    end
    ordered = { "lootSelf", "lootPushedSelf", "lootBonusSelf", "lootCreatedSelf" }
    for _, key in ipairs(ordered) do
        if patterns[key] then
            item = msg:match(patterns[key])
            if item then return item, 1 end
        end
    end
    return nil
end

local function ParseMoneyMessage(msg)
    if not msg then return nil end
    for _, key in ipairs({ "moneyYou", "moneyYouGuild", "moneySplit", "moneySplitGuild" }) do
        if patterns[key] then
            local amount = msg:match(patterns[key])
            if amount then return amount end
        end
    end
    return nil
end

local function ParseMoneyTextToCopper(amountText)
    amountText = StripColorCodes(amountText or "")
    if amountText == "" then return nil end

    amountText = amountText:gsub("|T.-|t", " ")
    amountText = amountText:gsub(" +", " ")

    local found = false

    local function extractAmount(patternKey, symbol)
        local value
        local pattern = patterns[patternKey]
        if pattern then
            value = amountText:match(pattern)
        end
        if not value and symbol and symbol ~= "" then
            local escapedSymbol = EscapeLuaPattern(symbol)
            value = amountText:match("(%d[%d,]*)%s*" .. escapedSymbol)
        end
        if value then
            found = true
            return ParseNumeric(value)
        end
        return 0
    end

    local gold = extractAmount("goldAmount", GOLD_AMOUNT_SYMBOL)
    local silver = extractAmount("silverAmount", SILVER_AMOUNT_SYMBOL)
    local copper = extractAmount("copperAmount", COPPER_AMOUNT_SYMBOL)

    if not found then
        return nil
    end

    return (gold * COPPER_PER_GOLD) + (silver * COPPER_PER_SILVER) + copper
end

local COIN_ICON_SIZE = 11

local function ApplyCoinTextureSize(textureText)
    if not textureText or textureText == "" then return textureText end
    return (textureText:gsub("(|T[^:|]+:)(%-?%d*):(%-?%d*)", function(prefix)
        return prefix .. COIN_ICON_SIZE .. ":" .. COIN_ICON_SIZE
    end))
end

local function FormatCopperAsPlainText(copper)
    copper = math.max(0, tonumber(copper) or 0)

    local gold = math.floor(copper / COPPER_PER_GOLD)
    copper = copper % COPPER_PER_GOLD
    local silver = math.floor(copper / COPPER_PER_SILVER)
    copper = copper % COPPER_PER_SILVER

    local goldSymbol = tostring(GOLD_AMOUNT_SYMBOL or "g")
    local silverSymbol = tostring(SILVER_AMOUNT_SYMBOL or "s")
    local copperSymbol = tostring(COPPER_AMOUNT_SYMBOL or "c")

    if gold > 0 then
        return string.format("%s%s %d%s %d%s", FormatNumber(gold), goldSymbol, silver, silverSymbol, copper, copperSymbol)
    end
    if silver > 0 then
        return string.format("%d%s %d%s", silver, silverSymbol, copper, copperSymbol)
    end
    return string.format("%d%s", copper, copperSymbol)
end

local function FormatCopperForMoneyDisplay(copper, useIcons)
    copper = math.max(0, tonumber(copper) or 0)

    if useIcons and GetCoinTextureString then
        local ok, coins = pcall(GetCoinTextureString, copper)
        if ok and type(coins) == "string" and coins ~= "" then
            return ApplyCoinTextureSize(coins)
        end
    end

    return FormatCopperAsPlainText(copper)
end

GetMoneyPreviewText = function()
    return FormatCopperForMoneyDisplay(123450, db and db.showMoneyIcons)
end

local function FormatMoneyNotificationText(amountText)
    if not amountText or amountText == "" then return amountText end

    local copper = ParseMoneyTextToCopper(amountText)
    if copper == nil then
        return amountText
    end

    return FormatCopperForMoneyDisplay(copper, db and db.showMoneyIcons)
end

local function ParseCurrencyMessage(msg)
    if not msg then return nil end
    local currencyText, count
    for _, key in ipairs({ "currencyMultiple", "currencyMultipleBonus", "currencySingle", "currencySingleBonus" }) do
        if patterns[key] then
            currencyText, count = msg:match(patterns[key])
            if currencyText then return currencyText, tonumber(count) or 1 end
        end
    end
    return nil
end
local function ShowLootMessageQuest(itemText, amount, qFulfilled, qRequired)
    if db and db.showQuestItems == false then
        return
    end

    amount = amount or 1
    local itemKey, itemQuery = GetItemKeyAndQuery(itemText)
    local itemName = ExtractBracketName(itemText) or itemText
    local displayItemText = GetLootDisplayItemText(itemText or itemName or "Item")
    local iconPrefix = GetLootItemIconPrefix(itemQuery)

    local fulfilled = tonumber(qFulfilled) or 0
    local required = tonumber(qRequired) or 0
    if required <= 0 then
        ShowCenterText(string.format("%dx %s%s", amount, iconPrefix, displayItemText or itemName or "Item"), "loot", "loot")
        return
    end

    local suffix = FormatLootDisplaySuffix(fulfilled, required)
    ShowCenterText(string.format("%dx %s%s%s", amount, iconPrefix, displayItemText or itemName or "Item", suffix), "loot", "loot")
end


local function IsQuestItemClass(itemID)
    if not itemID or not GetItemInfoInstant then return false end
    local _, _, _, _, _, classID = GetItemInfoInstant(itemID)
    local QUEST_CLASS = _G.LE_ITEM_CLASS_QUESTITEM or 12
    return classID == QUEST_CLASS
end

local EQUIP_LOC_TO_INVENTORY_SLOTS = {
    INVTYPE_HEAD = { INVSLOT_HEAD },
    INVTYPE_NECK = { INVSLOT_NECK },
    INVTYPE_SHOULDER = { INVSLOT_SHOULDER },
    INVTYPE_CLOAK = { INVSLOT_BACK },
    INVTYPE_CHEST = { INVSLOT_CHEST },
    INVTYPE_ROBE = { INVSLOT_CHEST },
    INVTYPE_WRIST = { INVSLOT_WRIST },
    INVTYPE_HAND = { INVSLOT_HAND },
    INVTYPE_WAIST = { INVSLOT_WAIST },
    INVTYPE_LEGS = { INVSLOT_LEGS },
    INVTYPE_FEET = { INVSLOT_FEET },
    INVTYPE_FINGER = { INVSLOT_FINGER1, INVSLOT_FINGER2 },
    INVTYPE_TRINKET = { INVSLOT_TRINKET1, INVSLOT_TRINKET2 },
    INVTYPE_WEAPON = { INVSLOT_MAINHAND, INVSLOT_OFFHAND },
    INVTYPE_2HWEAPON = { INVSLOT_MAINHAND },
    INVTYPE_WEAPONMAINHAND = { INVSLOT_MAINHAND },
    INVTYPE_WEAPONOFFHAND = { INVSLOT_OFFHAND },
    INVTYPE_SHIELD = { INVSLOT_OFFHAND },
    INVTYPE_HOLDABLE = { INVSLOT_OFFHAND },
    INVTYPE_RANGED = { INVSLOT_MAINHAND },
    INVTYPE_RANGEDRIGHT = { INVSLOT_MAINHAND },
    INVTYPE_THROWN = { INVSLOT_MAINHAND },
    INVTYPE_RELIC = { INVSLOT_MAINHAND },
}

local ARMOR_EQUIP_LOCS_REQUIRING_MATCH = {
    INVTYPE_HEAD = true,
    INVTYPE_SHOULDER = true,
    INVTYPE_CHEST = true,
    INVTYPE_ROBE = true,
    INVTYPE_WRIST = true,
    INVTYPE_HAND = true,
    INVTYPE_WAIST = true,
    INVTYPE_LEGS = true,
    INVTYPE_FEET = true,
}

local PLAYER_CLASS_TO_ARMOR_SUBCLASS = {
    PRIEST = (_G.LE_ITEM_ARMOR_CLOTH or 1),
    MAGE = (_G.LE_ITEM_ARMOR_CLOTH or 1),
    WARLOCK = (_G.LE_ITEM_ARMOR_CLOTH or 1),

    ROGUE = (_G.LE_ITEM_ARMOR_LEATHER or 2),
    DRUID = (_G.LE_ITEM_ARMOR_LEATHER or 2),
    MONK = (_G.LE_ITEM_ARMOR_LEATHER or 2),
    DEMONHUNTER = (_G.LE_ITEM_ARMOR_LEATHER or 2),

    HUNTER = (_G.LE_ITEM_ARMOR_MAIL or 3),
    SHAMAN = (_G.LE_ITEM_ARMOR_MAIL or 3),
    EVOKER = (_G.LE_ITEM_ARMOR_MAIL or 3),

    PALADIN = (_G.LE_ITEM_ARMOR_PLATE or 4),
    WARRIOR = (_G.LE_ITEM_ARMOR_PLATE or 4),
    DEATHKNIGHT = (_G.LE_ITEM_ARMOR_PLATE or 4),
}

local function GetEffectiveItemLevel(itemRef)
    if not itemRef then return nil end
    if GetDetailedItemLevelInfo then
        local ok, level = pcall(GetDetailedItemLevelInfo, itemRef)
        if ok and tonumber(level) then
            return tonumber(level)
        end
    end
    if GetItemInfo then
        local _, _, _, level = GetItemInfo(itemRef)
        if tonumber(level) then
            return tonumber(level)
        end
    end
    return nil
end

local function GetItemEquipLocation(itemID, itemText)
    if GetItemInfoInstant and itemID then
        local _, _, _, equipLoc = GetItemInfoInstant(itemID)
        if type(equipLoc) == "string" and equipLoc ~= "" then
            return equipLoc
        end
    end
    if GetItemInfo then
        local _, _, _, _, _, _, _, _, equipLoc = GetItemInfo(itemText or itemID)
        if type(equipLoc) == "string" and equipLoc ~= "" then
            return equipLoc
        end
    end
    return nil
end

local function GetPlayerPreferredArmorSubclass()
    local _, classFile = UnitClass("player")
    if type(classFile) ~= "string" or classFile == "" then
        return nil
    end
    return PLAYER_CLASS_TO_ARMOR_SUBCLASS[classFile]
end

local function ItemMatchesPlayerArmorType(itemText, itemID, equipLoc)
    equipLoc = equipLoc or GetItemEquipLocation(itemID, itemText)
    if not equipLoc or not ARMOR_EQUIP_LOCS_REQUIRING_MATCH[equipLoc] then
        return true
    end

    local preferredSubclass = GetPlayerPreferredArmorSubclass()
    if not preferredSubclass then
        return true
    end

    if not itemID or not GetItemInfoInstant then
        return true
    end

    local _, _, _, _, _, classID, subClassID = GetItemInfoInstant(itemID)
    local armorClassID = _G.LE_ITEM_CLASS_ARMOR or 4
    if classID ~= armorClassID then
        return true
    end

    return subClassID == preferredSubclass
end

local function ShouldShowUpgradeArrow(itemText, itemID)
    if not db or not db.showUpgradeArrow then return false end
    local equipLoc = GetItemEquipLocation(itemID, itemText)
    if not equipLoc then return false end

    local slots = EQUIP_LOC_TO_INVENTORY_SLOTS[equipLoc]
    if type(slots) ~= "table" or #slots == 0 then
        return false
    end

    if not ItemMatchesPlayerArmorType(itemText, itemID, equipLoc) then
        return false
    end

    local newItemLevel = GetEffectiveItemLevel(itemText or itemID)
    if not newItemLevel or newItemLevel <= 0 then
        return false
    end

    for _, inventorySlot in ipairs(slots) do
        local equippedLink = GetInventoryItemLink("player", inventorySlot)
        if not equippedLink then
            return true
        end

        local equippedItemLevel = GetEffectiveItemLevel(equippedLink) or 0
        if newItemLevel > equippedItemLevel then
            return true
        end
    end

    return false
end

local function GetUpgradeArrowPrefix()
    local texturePath = "Interface\\AddOns\\" .. tostring(ADDON_NAME or "LootBT") .. "\\Media\\upgrade_arrow"
    return "|T" .. texturePath .. ":14:14:0:0|t "
end


local function ShowLootMessage(itemText, amount)
    amount = amount or 1
    local itemKey, itemQuery = GetItemKeyAndQuery(itemText)
    local itemID = type(itemQuery) == "number" and itemQuery or nil
    local itemName = ExtractBracketName(itemText) or itemText

    if db and db.showQuestItems == false and IsQuestItemClass(itemID) then
        return
    end

    local displayItemText = GetLootDisplayItemText(itemText or itemName or "Item")
    local predictedTotal

    if itemKey and not IsQuestItemClass(itemID) then
        local actual = GetActualItemCount(itemQuery)
        local base = math.max(actual, predictedItemTotals[itemKey] or 0)
        predictedTotal = base + amount
        predictedItemTotals[itemKey] = predictedTotal
    end

    if db.hideGreys and itemID then
        local quality
        if C_Item and C_Item.GetItemQualityByID then
            local ok, q = pcall(C_Item.GetItemQualityByID, itemID)
            if ok then
                quality = q
            end
        end
        if quality == nil and GetItemInfo then
            local _, _, q = GetItemInfo(itemID)
            quality = q
        end
        if quality == 0 then
            return
        end
    end

    local suffix = predictedTotal and FormatLootDisplaySuffix(predictedTotal) or ""
    local arrowPrefix = ShouldShowUpgradeArrow(itemText, itemID) and GetUpgradeArrowPrefix() or ""
    local iconPrefix = GetLootItemIconPrefix(itemQuery)

    ShowCenterText(string.format("%dx %s%s%s%s", amount, arrowPrefix, iconPrefix, displayItemText or "Item", suffix), "loot", "loot")
end

local function ShowCurrencyMessage(currencyText, amount)
    amount = amount or 1
    local currencyID, name = GetCurrencyIDAndName(currencyText)
    local total
    if currencyID then
        local actual = GetActualCurrencyCount(currencyID)
        total = actual

        if total ~= nil then
            predictedCurrencyTotals[currencyID] = total
        else
            local predicted = (predictedCurrencyTotals[currencyID] or 0) + amount
            predictedCurrencyTotals[currencyID] = predicted
            total = predicted
        end
    end
    ShowCenterText(FormatCurrencyDisplayText(name or ExtractBracketName(currencyText) or "Currency", amount, total), "currency", "currency")
end

local function FlushCurrencyBatch(batchKey, sequence)
    local batch = pendingCurrencyBatches[batchKey]
    if not batch or batch.sequence ~= sequence then return end

    pendingCurrencyBatches[batchKey] = nil
    ShowCurrencyMessage(batch.currencyText, batch.amount)
end

local function QueueCurrencyMessage(currencyText, amount)
    amount = amount or 1

    if not (C_Timer and C_Timer.After) then
        ShowCurrencyMessage(currencyText, amount)
        return
    end

    local currencyID, name = GetCurrencyIDAndName(currencyText)
    local batchKey = currencyID and ("currency:" .. currencyID) or ("text:" .. tostring(name or currencyText or "currency"))
    local batch = pendingCurrencyBatches[batchKey]

    if batch then
        batch.amount = (batch.amount or 0) + amount
        batch.currencyText = currencyText or batch.currencyText
        batch.sequence = (batch.sequence or 0) + 1
    else
        batch = {
            currencyText = currencyText,
            amount = amount,
            sequence = 1,
        }
        pendingCurrencyBatches[batchKey] = batch
    end

    local sequence = batch.sequence
    C_Timer.After(CURRENCY_BATCH_DELAY, function()
        FlushCurrencyBatch(batchKey, sequence)
    end)
end

local function ShortenReputationMessage(msg)
    local ok, text, isLoss, faction, amount = pcall(function()
        if msg == nil then
            return nil, false, nil, nil
        end

        local function buildResult(name, value, losing)
            name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
            local numericAmount = ParseNumeric(value)
            return string.format("%s Rep %s%s", name, losing and "-" or "+", FormatNumber(numericAmount)), losing and true or false, name, numericAmount
        end

        local name, value

        name, value = msg:match("^Your Warband's reputation with (.+) increased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, false)
        end

        name, value = msg:match("^Your Warband's reputation with (.+) decreased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, true)
        end

        name, value = msg:match("^Your reputation with (.+) has increased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, false)
        end

        name, value = msg:match("^Your reputation with (.+) has decreased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, true)
        end

        name, value = msg:match("^Your reputation with (.+) increased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, false)
        end

        name, value = msg:match("^Your reputation with (.+) decreased by ([%d,]+)%.?$")
        if name then
            return buildResult(name, value, true)
        end

        local lower = msg:lower()
        name, value = msg:match("with (.+) .- by ([%d,]+)%.?$")
        if name and value then
            return buildResult(name, value, lower:find("decreased") or lower:find("lost"))
        end

        return msg, not not (lower:find("decreased") or lower:find("lost")), nil, nil
    end)

    if ok then
        return text, isLoss, faction, amount
    end

    return nil, false, nil, nil
end

local DELVE_COMPANION_FACTIONS = {
    ["brann bronzebeard"] = true,
    ["brann"] = true,
    ["valeera sanguinar"] = true,
    ["valeera sanguinaar"] = true,
    ["valeera"] = true,
}

local function IsDelveCompanionMessage(msg)
    local text = tostring(msg or "")
    local lower = text:lower()
    if lower:find("delve companion", 1, true) or lower:find("companion experience", 1, true) then
        return true
    end

    local faction = text:match("^(.+) has gained [%d,]+ experience%.?$")
    if not faction then
        faction = text:match("^(.+) has lost [%d,]+ experience%.?$")
    end
    if faction then
        local normalized = tostring(faction):lower():gsub("^%s+", ""):gsub("%s+$", "")
        if DELVE_COMPANION_FACTIONS[normalized] then
            return true
        end
    end

    return false
end

local function ShouldShowReputationMessage(msg)
    if not db or not db.showReputation then
        return false
    end

    if db.showDelveCompanionXP then
        return true
    end

    if IsDelveCompanionMessage(msg) then
        return false
    end

    local _, _, faction = ShortenReputationMessage(msg)
    if faction then
        local normalized = tostring(faction):lower():gsub("^%s+", ""):gsub("%s+$", "")
        if DELVE_COMPANION_FACTIONS[normalized] then
            return false
        end
    end

    return true
end

local function FlushReputationBatch(batchKey, sequence)
    local batch = pendingReputationBatches[batchKey]
    if not batch or batch.sequence ~= sequence then
        return
    end

    pendingReputationBatches[batchKey] = nil
    local text = string.format("%s Rep %s%s", batch.faction, batch.isLoss and "-" or "+", FormatNumber(batch.amount))
    ShowScrollText(FormatReputationDisplayText(text, batch.isLoss), batch.isLoss and "repLoss" or "repGain", nil, batch.isLoss and "repLoss" or "repGain")
end

local function QueueReputationMessage(msg)
    local short, isLoss, faction, amount = ShortenReputationMessage(msg)
    if not short or short == "" then
        return
    end

    local colorKey = isLoss and "repLoss" or "repGain"
    if not faction or not amount or amount <= 0 or not (C_Timer and C_Timer.After) then
        ShowScrollText(FormatReputationDisplayText(short, isLoss), colorKey, nil, colorKey)
        return
    end

    local batchKey = (isLoss and "loss:" or "gain:") .. faction:lower()
    local batch = pendingReputationBatches[batchKey]
    if batch then
        batch.amount = (batch.amount or 0) + amount
        batch.sequence = (batch.sequence or 0) + 1
    else
        batch = {
            faction = faction,
            amount = amount,
            isLoss = isLoss and true or false,
            sequence = 1,
        }
        pendingReputationBatches[batchKey] = batch
    end

    local sequence = batch.sequence
    C_Timer.After(REPUTATION_BATCH_DELAY, function()
        FlushReputationBatch(batchKey, sequence)
    end)
end

local function ShortenSkillMessage(msg)
    if not msg then return nil end
    local skill, rank = msg:match("^Your skill in (.+) has increased to (%d+)%.?$")
    if skill then
        return string.format("%s %s", skill, rank)
    end
    skill, rank = msg:match("^Your (.+) skill has increased to (%d+)%.?$")
    if skill then
        return string.format("%s %s", skill, rank)
    end
    skill, rank = msg:match("^(.+) has increased to (%d+)%.?$")
    if skill then
        return string.format("%s %s", skill, rank)
    end
    return msg
end


local function ResetPredictedCounts()
    wipe(predictedItemTotals)
    wipe(predictedCurrencyTotals)
end

local function ResetScrollQueue()
    wipe(pendingScrollQueue)
    scrollQueueArmed = false
    scrollQueueLastShownAt = 0
end

function addon.CanScheduleTimer()
    return C_Timer and type(C_Timer.After) == "function"
end

function addon.ScheduleAfter(delay, callback)
    if type(callback) ~= "function" then
        return false
    end

    delay = math.max(0, tonumber(delay) or 0)
    if addon.CanScheduleTimer() then
        C_Timer.After(delay, callback)
        return true
    end

    callback()
    return false
end

local function GetEffectiveMinimapShape()
    if type(GetMinimapShape) == "function" then
        local ok, shape = pcall(GetMinimapShape)
        if ok and shape then return tostring(shape):upper() end
    end
    if Minimap and Minimap.GetShape then
        local ok, shape = pcall(Minimap.GetShape, Minimap)
        if ok and shape then return tostring(shape):upper() end
    end
    return "ROUND"
end

local function PositionFallbackMinimapButton()
    if not minimapButton or not Minimap or (ldbIcon and ldbObject) then return end
    local angle = math.rad(db.minimapPos or defaults.minimapPos)
    local radius = 80
    local x = math.cos(angle) * radius
    local y = math.sin(angle) * radius
    if GetEffectiveMinimapShape() ~= "ROUND" then
        x = Clamp(x, -radius, radius)
        y = Clamp(y, -radius, radius)
    end
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function HandleMinimapButtonClick(buttonName)
    if buttonName == "MiddleButton" then
        db.showMinimap = false
        addon:RefreshMinimap()
        addon:SyncActiveProfile()
        addon:RefreshConfigUIs()
        return
    end

    if buttonName == "RightButton" then
        if InCombatLockdown() and not db.showAnchors then
            Print("Anchors cannot be unlocked in combat.")
            return
        end
        db.showAnchors = not db.showAnchors
        addon:UpdateAnchorVisuals()
        addon:SyncActiveProfile()
        addon:RefreshConfigUIs()
        return
    end

    addon:ToggleOptions()
end

local function AddMinimapTooltipLines(tt)
    if not tt then return end
    if tt.SetText then
        tt:SetText("LootBT", 1, 1, 1)
    else
        tt:AddLine("LootBT")
    end
    tt:AddLine("Left-click: open LootBT", 0.8, 0.8, 0.8)
    tt:AddLine("Right-click: toggle anchors", 0.8, 0.8, 0.8)
    tt:AddLine("Middle-click: hide this button", 0.8, 0.8, 0.8)
end


local function CreateFallbackMinimapButton()
    if minimapButton or not Minimap then return end
    local button = CreateFrame("Button", ADDON_NAME .. "MinimapButton", Minimap)
    button:SetSize(31, 31)
    button:SetFrameStrata("MEDIUM")
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    button:RegisterForDrag("LeftButton")

    button.icon = button:CreateTexture(nil, "BACKGROUND")
    button.icon:SetTexture("Interface\\Icons\\INV_Misc_Bag_10")
    button.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    button.icon:SetSize(20, 20)
    button.icon:SetPoint("CENTER")

    button.border = button:CreateTexture(nil, "OVERLAY")
    button.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    button.border:SetSize(54, 54)
    button.border:SetPoint("TOPLEFT")

    button.highlight = button:CreateTexture(nil, "HIGHLIGHT")
    button.highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    button.highlight:SetBlendMode("ADD")
    button.highlight:SetSize(38, 38)
    button.highlight:SetPoint("CENTER", 0, 1)

    button:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            mx = mx / scale
            my = my / scale
            local cx, cy = Minimap:GetCenter()
            db.minimapPos = math.deg(math.atan2(my - cy, mx - cx))
            db.minimap = db.minimap or {}
            db.minimap.minimapPos = db.minimapPos
            PositionFallbackMinimapButton()
        end)
    end)
    button:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        db.minimap = db.minimap or {}
        db.minimap.minimapPos = db.minimapPos
        addon:SyncActiveProfile()
    end)

    button:SetScript("OnClick", function(_, buttonName)
        HandleMinimapButtonClick(buttonName)
    end)

    button:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        AddMinimapTooltipLines(GameTooltip)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)

    minimapButton = button
end

local function SetupLibDBIcon()
    if ldbObject or not LibStub then return end
    local okLDB, LDB = pcall(function() return LibStub("LibDataBroker-1.1", true) end)
    local okDBI, DBI = pcall(function() return LibStub("LibDBIcon-1.0", true) end)
    if not okLDB or not okDBI or not LDB or not DBI then return end

    ldbObject = LDB:NewDataObject("LootBT", {
        type = "data source",
        text = "LootBT",
        icon = "Interface\\Icons\\INV_Misc_Bag_10",
        OnClick = function(_, buttonName)
            HandleMinimapButtonClick(buttonName)
        end,
        OnTooltipShow = function(tt)
            AddMinimapTooltipLines(tt)
        end,
    })
    ldbIcon = DBI
end

function addon:RefreshMinimap()
    db.minimap = db.minimap or {}

    if ldbIcon and ldbObject then
        if type(db.minimap.minimapPos) ~= "number" then
            db.minimap.minimapPos = db.minimapPos or defaults.minimapPos
        end
        db.minimapPos = db.minimap.minimapPos
        db.minimap.hide = not db.showMinimap

        if not ldbRegistered then
            ldbIcon:Register("LootBT", ldbObject, db.minimap)
            ldbRegistered = true
        elseif ldbIcon.Refresh then
            ldbIcon:Refresh("LootBT", db.minimap)
        end

        if db.showMinimap then
            ldbIcon:Show("LootBT")
        else
            ldbIcon:Hide("LootBT")
        end
        return
    end

    if type(db.minimapPos) ~= "number" then
        db.minimapPos = db.minimap.minimapPos or defaults.minimapPos
    end
    db.minimap.minimapPos = db.minimapPos
    db.minimap.hide = not db.showMinimap

    CreateFallbackMinimapButton()
    if minimapButton then
        minimapButton:SetShown(db.showMinimap and true or false)
        PositionFallbackMinimapButton()
    end
end

function addon:RunTest()
    ShowLootMessage("|cff1eff00|Hitem:6948::::::::1:::::::|h[Hearthstone]|h|r", 2)
    ShowCenterText(FormatCopperForMoneyDisplay(12345, db and db.showMoneyIcons), "money", "money")
    ShowCurrencyMessage("|cff66ccff|Hcurrency:3008:0|h[Valorstones]|h|r", 5)
    ShowScrollText(GetCombatEnterText(), "combatEnter", "combat", "combatEnter")
    addon.ScheduleAfter(0.15, function() ShowScrollText(FormatHonorDisplayText(25), "honor", nil, "honor") end)
    addon.ScheduleAfter(0.30, function() ShowScrollText(FormatReputationDisplayText("Guild Rep +125", false), "repGain", nil, "repGain") end)
    addon.ScheduleAfter(0.45, function() ShowScrollText("Midnight Leatherworking 40", "skill", nil, "skill") end)
    addon.ScheduleAfter(0.60, function() ShowScrollText(GetCombatLeaveText(), "combatLeave", "combat", "combatLeave") end)
end

function addon:ResetAll()
    if type(self.ResetCurrentProfileToDefaults) == "function" then
        self:ResetCurrentProfileToDefaults(true)
    else
        self:ApplyDefaultProfile(true)
    end
    Print("Settings reset.")
end

function addon:HandleSlash(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "" or msg == "config" or msg == "options" or msg == "menu" then
        self:ToggleOptions()
        return
    end
    if msg == "test" then
        self:RunTest()
        return
    end
    if msg == "anchors" then
        if InCombatLockdown() and not db.showAnchors then
            Print("Anchors cannot be unlocked in combat.")
            return
        end
        db.showAnchors = not db.showAnchors
        self:UpdateAnchorVisuals()
        self:SyncActiveProfile()
        self:RefreshConfigUIs()
        return
    end
    if msg == "blizz" or msg == "settings" then
        self:OpenSettingsCategory()
        return
    end
    if msg == "reset" then
        self:ResetAll()
        return
    end
    Print("Commands: /lootbt, /lootbt test, /lootbt anchors, /lootbt blizz, /lootbt reset")
end

function addon:OnEvent(event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name ~= ADDON_NAME then return end

        BuildFontCatalog()
        defaults.colors = DeepCopy(DEFAULT_COLORS)
        local hadExistingDatabase = type(LootBTDB) == "table"
        LootBTDB = CopyDefaults(defaults, LootBTDB or {})
        db = LootBTDB
        if db._firstUseAnchorUnlockDone == nil then
            db._firstUseAnchorUnlockDone = hadExistingDatabase and true or false
        end
        addon.firstRunAnchorUnlock = not db._firstUseAnchorUnlockDone
        if addon.firstRunAnchorUnlock then
            db._firstUseAnchorUnlockDone = true
        end
        SanitizeRuntimeConfig()
        if db.lootAnchorX ~= nil and db.stackAnchorX == nil then
            db.stackAnchorX = db.lootAnchorX
        end
        if db.lootAnchorY ~= nil and db.stackAnchorY == nil then
            db.stackAnchorY = db.lootAnchorY
        end
        if db.lootAnchorX ~= nil or db.lootAnchorY ~= nil then
            db.lootAnchorX = nil
            db.lootAnchorY = nil
        end

        db.colors = NormalizeColorTable(CopyDefaults(DEFAULT_COLORS, db.colors or {}))
        db.minimap = CopyDefaults(defaults.minimap, db.minimap or {})
        SanitizeRuntimeConfig()
        self:NormalizeProfilesState()
        if db.showMinimap == nil then
            db.showMinimap = not db.minimap.hide
        end
        if db.minimap.minimapPos then
            db.minimapPos = db.minimap.minimapPos
        end

        EnsureAnchors()
        RebuildPatterns()
        self:CreateStandaloneOptions()
        self:CreateSettingsPanel()
        SetupLibDBIcon()
        db.showAnchors = addon.firstRunAnchorUnlock and true or false
        self:UpdateAnchorVisuals()
        self:RefreshMinimap()
        self:RefreshConfigUIs()

        SLASH_LOOTBT1 = "/lootbt"
        SLASH_LOOTBT2 = "/lsbt"
        SlashCmdList.LOOTBT = function(input) addon:HandleSlash(input) end

        self:UnregisterEvent("ADDON_LOADED")
        return
    end

    if event == "PLAYER_LOGIN" then
        BuildFontCatalog(true)
        if type(self.GetCurrentCharacterProfileKey) == "function" then
            self:GetCurrentCharacterProfileKey()
        end
        ResetScrollQueue()
        if type(self.ResetQuestLootBatchState) == "function" then
            self.ResetQuestLootBatchState()
        end
        self:ApplyStoredProfileForCurrentCharacter()
        db.showAnchors = addon.firstRunAnchorUnlock and true or false
        addon.firstRunAnchorUnlock = false
        self:UpdateAnchorVisuals()
        self:RefreshMinimap()
        self:RefreshConfigUIs()
        return
    end

    if event == "PLAYER_REGEN_DISABLED" then
        local panel = type(self.GetStandaloneOptionsPanel) == "function" and self:GetStandaloneOptionsPanel() or nil
        if panel and panel:IsShown() then
            panel:Hide()
            Print("Menu closed due to combat.")
        end
        if db.showAnchors then
            db.showAnchors = false
            self:UpdateAnchorVisuals()
            self:RefreshConfigUIs()
        end
        if db.showCombat then
            ShowScrollText(GetCombatEnterText(), "combatEnter", "combat", "combatEnter")
        end
        return
    end

    if event == "PLAYER_REGEN_ENABLED" then
        if db.showCombat then
            ShowScrollText(GetCombatLeaveText(), "combatLeave", "combat", "combatLeave")
        end
        return
    end

    if event == "BAG_UPDATE_DELAYED" or event == "CURRENCY_DISPLAY_UPDATE" then
        ResetPredictedCounts()
        return
    end

    if event == "CHAT_MSG_LOOT" then
        if not db.showLoot then return end
        local msg = ...
        local itemText, amount = ParseLootMessage(msg)
        if itemText then
            if type(self.HandleLootChatMessage) == "function" then
                self.HandleLootChatMessage(itemText, amount)
            else
                ShowLootMessage(itemText, amount)
            end
        end
        return
    end

    if event == "CHAT_MSG_MONEY" then
        if not db.showMoney then return end
        local msg = ...
        local amountText = ParseMoneyMessage(msg)
        if amountText then ShowCenterText(FormatMoneyNotificationText(amountText), "money", "money") end
        return
    end

    if event == "CHAT_MSG_CURRENCY" then
        if not db.showCurrency then return end
        local msg = ...
        local currencyText, amount = ParseCurrencyMessage(msg)
        if currencyText then QueueCurrencyMessage(currencyText, amount) end
        return
    end

    if event == "CHAT_MSG_COMBAT_HONOR_GAIN" then
        if db.showHonor then
            local msg = ...
            local amount = msg and (msg:match("([%d,]+)") or nil)
            if amount then
                ShowScrollText(FormatHonorDisplayText(ParseNumeric(amount)), "honor", nil, "honor")
            else
                ShowScrollText(msg, "honor", nil, "honor")
            end
        end
        return
    end

    if event == "CHAT_MSG_COMBAT_FACTION_CHANGE" then
        local msg = ...
        if ShouldShowReputationMessage(msg) then
            QueueReputationMessage(msg)
        end
        return
    end

    if event == "CHAT_MSG_SKILL" then
        if db.showSkill then
            ShowScrollText(ShortenSkillMessage(...), "skill", nil, "skill")
        end
        return
    end

end

function addon.GetDefaults()
    return defaults
end

function addon:PumpQueues()
    if PumpStackQueue then
        PumpStackQueue()
    end
    if PumpScrollQueue then
        PumpScrollQueue()
    end
end

addon.LayoutLootMessages = LayoutLootMessages

U.GetDefaults = addon.GetDefaults
U.GetDB = function()
    return db
end
U.DeepCopy = DeepCopy
U.SanitizeRuntimeConfig = SanitizeRuntimeConfig
U.ResetPredictedCounts = ResetPredictedCounts
U.Clamp = Clamp
U.CreateBackdrop = CreateBackdrop
U.BuildFontCatalog = BuildFontCatalog
U.NormalizeFontKey = NormalizeFontKey
U.GetFontLabelByKey = GetFontLabelByKey
U.GetColorForKey = GetColorForKey
U.SetColorForKey = SetColorForKey
U.SetMessageFont = SetMessageFont
U.GetMoneyPreviewText = GetMoneyPreviewText
U.GetLootPreviewText = GetLootPreviewText
U.ShouldUseSimpleAutoSymbols = ShouldUseSimpleAutoSymbols
U.FormatCurrencyDisplayText = FormatCurrencyDisplayText
U.FormatHonorDisplayText = FormatHonorDisplayText
U.FormatReputationDisplayText = FormatReputationDisplayText
U.GetCombatEnterText = GetCombatEnterText
U.GetCombatLeaveText = GetCombatLeaveText
U.Print = Print
U.EscapeLuaPattern = EscapeLuaPattern
U.ExtractBracketName = ExtractBracketName
U.GetItemKeyAndQuery = GetItemKeyAndQuery
U.IsQuestItemClass = IsQuestItemClass
U.ShowLootMessage = ShowLootMessage
U.ShowLootMessageQuest = ShowLootMessageQuest
U.SetAnchorUnlockState = addon.SetAnchorUnlockState

addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("BAG_UPDATE_DELAYED")
addon:RegisterEvent("CURRENCY_DISPLAY_UPDATE")
addon:RegisterEvent("CHAT_MSG_LOOT")
addon:RegisterEvent("CHAT_MSG_MONEY")
addon:RegisterEvent("CHAT_MSG_CURRENCY")
addon:RegisterEvent("PLAYER_REGEN_DISABLED")
addon:RegisterEvent("PLAYER_REGEN_ENABLED")
addon:RegisterEvent("CHAT_MSG_COMBAT_HONOR_GAIN")
addon:RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE")
addon:RegisterEvent("CHAT_MSG_SKILL")
addon:SetScript("OnEvent", function(_, event, ...)
    addon:OnEvent(event, ...)
end)
