local ADDON_NAME, ns = ...
ns = ns or {}

local U = ns.U or {}
local addon = ns.addon
if not addon then
    return
end

local backdropTemplate = BackdropTemplateMixin and "BackdropTemplate" or nil
local optionsPanel
local settingsPanel
local settingsCategory
local configUIs = {}

local function GetDB()
    return U.GetDB and U.GetDB() or nil
end

local Clamp = U.Clamp
local CreateBackdrop = U.CreateBackdrop
local BuildFontCatalog = U.BuildFontCatalog
local NormalizeFontKey = U.NormalizeFontKey
local GetFontLabelByKey = U.GetFontLabelByKey
local GetColorForKey = U.GetColorForKey
local SetColorForKey = U.SetColorForKey
local SetMessageFont = U.SetMessageFont
local GetMoneyPreviewText = U.GetMoneyPreviewText
local GetLootPreviewText = U.GetLootPreviewText
local ShouldUseSimpleAutoSymbols = U.ShouldUseSimpleAutoSymbols
local FormatCurrencyDisplayText = U.FormatCurrencyDisplayText
local FormatHonorDisplayText = U.FormatHonorDisplayText
local FormatReputationDisplayText = U.FormatReputationDisplayText
local GetCombatEnterText = U.GetCombatEnterText
local GetCombatLeaveText = U.GetCombatLeaveText
local IsReservedProfileName = U.IsReservedProfileName
local DEFAULT_PROFILE_NAME = U.DEFAULT_PROFILE_NAME or "Default"
local Print = U.Print

local CreateLabel = U.CreateLabel
local CreateButton = U.CreateButton
local CreateCheckbox = U.CreateCheckbox
local CreateEditBox = U.CreateEditBox
local SetDropdownEnabled = U.SetDropdownEnabled
local SetDropdownDisplayTextToDefaultFont = U.SetDropdownDisplayTextToDefaultFont
local CreateFontDropdown = U.CreateFontDropdown
local CreateFontDropdownRow = U.CreateFontDropdownRow
local CreateSlider = U.CreateSlider
local CreateColorRow = U.CreateColorRow
local HideAllDropdownDeleteButtons = U.HideAllDropdownDeleteButtons
local GetLatestDropdownListButton = U.GetLatestDropdownListButton
local StyleFontDropdownMenuButton = U.StyleFontDropdownMenuButton


local function AddProfilePersistenceWarning(ui, host, xOffset, yOffset)
    local defaultText = "Warning: For changes to persist between logins, you must use a profile other than Default."
    local savedText = "Changes are automatically saved to your current profile."
    local warning = CreateLabel(host, defaultText, "GameFontNormalLarge")
    warning:SetPoint("BOTTOM", host, "BOTTOM", xOffset or 0, yOffset or 12)
    warning:SetWidth(540)
    warning:SetJustifyH("CENTER")

    local function refreshWarning()
        local db = GetDB()
        local current = db and db.lastProfile
        if IsReservedProfileName(current or DEFAULT_PROFILE_NAME) then
            if warning.SetFontObject then
                warning:SetFontObject(GameFontNormalLarge)
            end
            warning:SetText(defaultText)
            warning:SetTextColor(1.0, 0.18, 0.18)
        else
            if warning.SetFontObject then
                warning:SetFontObject(GameFontHighlight)
            end
            warning:SetText(savedText)
            warning:SetTextColor(0.45, 1.0, 0.45)
        end
        warning:Show()
    end

    table.insert(ui.refreshers, refreshWarning)
    return warning
end

local function PrepareCenteredCheckbox(box, width)
    width = width or 280
    if box.label then
        box.label:ClearAllPoints()
        box.label:SetPoint("LEFT", box, "RIGHT", 4, 1)
        box.label:SetWidth(math.max(80, width - 28))
        box.label:SetJustifyH("LEFT")
    end
    return box
end

local function PlaceCenteredCheckbox(box, host, y, width, xOffset)
    width = width or 280
    PrepareCenteredCheckbox(box, width)
    box:ClearAllPoints()
    box:SetPoint("TOPLEFT", host, "TOP", (xOffset or 0) - math.floor(width / 2), y)
    return box
end

local function PlaceCenteredControl(frame, host, y, xOffset)
    frame:ClearAllPoints()
    frame:SetPoint("TOP", host, "TOP", xOffset or 0, y)
    return frame
end

local function AddBottomActionButtons(host, resetFunc, resetX, testX, resetY, testY)
    local testBtn = CreateButton(host, "Test notifications", 140, function()
        addon:RunTest()
    end)

    if resetFunc then
        local resetBtn = CreateButton(host, "Reset to defaults", 140, function()
            resetFunc()
        end)
        resetBtn:SetPoint("BOTTOM", host, "BOTTOM", resetX or -78, resetY or 18)
        testBtn:SetPoint("LEFT", resetBtn, "RIGHT", 12, 0)
        return resetBtn, testBtn
    end

    testBtn:SetPoint("BOTTOM", host, "BOTTOM", testX or 0, testY or 18)
    return nil, testBtn
end

local TAB_DEFS = {
    { key = "notifications", label = "Notifications" },
    { key = "layout", label = "Layout" },
    { key = "colors", label = "Colors" },
    { key = "customize", label = "Customize" },
    { key = "profiles", label = "Profiles" },
}

local COLOR_ROWS = {
    { key = "loot", label = "Loot", sample = GetLootPreviewText and GetLootPreviewText() or "1x |cffa335ee|Hitem:50818::::::::1:::::::|h[Invincible's Reins]|h|r (1)" },
    { key = "money", label = "Money", sample = "12g 34s 50c" },
    { key = "currency", label = "Currency", sample = "+5 Valorstones (1,245)" },
    { key = "combatEnter", label = "Combat Start", sample = "Entering Combat" },
    { key = "combatLeave", label = "Combat End", sample = "Leaving Combat" },
    { key = "honor", label = "Honor", sample = "+25 Honor" },
    { key = "repGain", label = "Rep Gain", sample = "Guild Rep +125" },
    { key = "repLoss", label = "Rep Loss", sample = "Guild Rep -125" },
    { key = "skill", label = "Skill", sample = "Midnight Leatherworking 40" },
}

local function CreateConfigShell(parent, isStandalone)
    local ui = { checkboxes = {}, sliders = {}, colorRows = {}, editBoxes = {}, fontRows = {}, pages = {}, tabs = {}, refreshers = {}, parent = parent }

    local title = CreateLabel(parent, "LootBT", "GameFontNormalLarge")
    if isStandalone then
        title:SetPoint("TOP", 0, -14)
        local subtitle = CreateLabel(parent, "/lootbt to show or hide this window", "GameFontHighlightSmall")
        subtitle:SetPoint("TOP", title, "BOTTOM", 0, -4)
        local close = CreateFrame("Button", nil, parent, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        ui.close = close
    else
        title:SetPoint("TOPLEFT", 16, -10)
        local subtitle = CreateLabel(parent, "The same controls also live in /lootbt.", "GameFontHighlightSmall")
        subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    end

    local tabBar = CreateFrame("Frame", nil, parent)
    tabBar:SetPoint("TOPLEFT", parent, "TOPLEFT", 16, isStandalone and -44 or -40)
    tabBar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -16, isStandalone and -44 or -40)
    tabBar:SetHeight(24)

    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", tabBar, "BOTTOMLEFT", 0, -8)
    scroll:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -30, 16)
    if scroll.EnableMouseWheel then
        scroll:EnableMouseWheel(true)
        scroll:SetScript("OnMouseWheel", function(self, delta)
            local cur = self:GetVerticalScroll() or 0
            local minVal, maxVal = 0, 0
            if self.ScrollBar and self.ScrollBar.GetMinMaxValues then
                minVal, maxVal = self.ScrollBar:GetMinMaxValues()
            elseif self.GetMinMaxValues then
                minVal, maxVal = self:GetMinMaxValues()
            end
            self:SetVerticalScroll(Clamp(cur - delta * 28, minVal or 0, maxVal or 0))
        end)
    end
    ui.scroll = scroll

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(1, 1)
    scroll:SetScrollChild(content)
    ui.content = content

    local function ShowPage(key)
        ui.activePage = key
        local page = ui.pages[key]
        local width = math.max(560, parent:GetWidth() - 70)
        local height = (page and page.contentHeight) or 1
        content:SetSize(width, height)
        for name, child in pairs(ui.pages) do
            child:SetSize(width, child.contentHeight or height)
            child:SetShown(name == key)
        end
        if scroll.SetVerticalScroll then
            scroll:SetVerticalScroll(0)
        end
        for name, button in pairs(ui.tabs) do
            if name == key then
                if button.LockHighlight then button:LockHighlight() end
                if button.SetButtonState then button:SetButtonState("PUSHED", true) end
            else
                if button.UnlockHighlight then button:UnlockHighlight() end
                if button.SetButtonState then button:SetButtonState("NORMAL") end
            end
        end
    end
    ui.ShowPage = ShowPage

    local prev
    local tabWidth = 100
    local tabSpacing = 6
    for _, def in ipairs(TAB_DEFS) do
        local b = CreateButton(tabBar, def.label, tabWidth, function() ShowPage(def.key) end)
        if prev then
            b:SetPoint("LEFT", prev, "RIGHT", tabSpacing, 0)
        else
            b:SetPoint("LEFT", tabBar, "LEFT", 0, 0)
        end
        ui.tabs[def.key] = b
        prev = b

        local page = CreateFrame("Frame", nil, content)
        page:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
        page:SetPoint("TOPRIGHT", content, "TOPRIGHT", 0, 0)
        page:Hide()
        ui.pages[def.key] = page
    end

    return ui
end

local function BuildNotificationsPage(ui)
    local page = ui.pages.notifications
    local host = CreateFrame("Frame", nil, page)
    host:SetPoint("TOP", page, "TOP", 16, 0)
    host:SetPoint("BOTTOM", page, "BOTTOM", 0, 0)
    host:SetWidth(560)

    local y = -8

    local resetBtn, testBtn = AddBottomActionButtons(host, function()
        addon:ResetNotificationsTab()
    end, -78, 78, 8, 8)

    local anchorsBox = CreateCheckbox(host, "Show / unlock anchors", function()
        local db = GetDB()
        return db and db.showAnchors
    end, function(v)
        addon.SetAnchorUnlockState(v and true or false)
    end)
    PlaceCenteredCheckbox(anchorsBox, host, y, 280, 0)
    table.insert(ui.checkboxes, anchorsBox)
    y = y - 40

    local function addHeading(text)
        local h = CreateLabel(host, text, "GameFontNormal")
        h:SetPoint("TOP", host, "TOP", 0, y)
        h:SetWidth(560)
        h:SetJustifyH("CENTER")
        y = y - 26
        return h
    end

    local function addBox(label, key, width, xOffset)
        local box = CreateCheckbox(host, label, function()
            local db = GetDB()
            return db and db[key]
        end, function(v)
            local db = GetDB()
            if not db then return end
            db[key] = v
            if key == "showMinimap" then
                addon:RefreshMinimap()
            end
            addon:RefreshConfigUIs()
        end)
        PlaceCenteredCheckbox(box, host, y, width or 280, xOffset or 0)
        table.insert(ui.checkboxes, box)
        y = y - 28
        return box
    end

    addHeading("Stacked")

    local linkedLeftWidth = 180
    local linkedLeftOffset = -50
    local linkedRightWidth = 220
    local linkedRightOffset = 140

    local lootRowY = y
    local lootBox = CreateCheckbox(host, "Looted items", function()
        local db = GetDB()
        return db and db.showLoot
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showLoot = v
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(lootBox, host, lootRowY, linkedLeftWidth, linkedLeftOffset)
    table.insert(ui.checkboxes, lootBox)

    local upgradeBox = CreateCheckbox(host, "Show upgrade arrow", function()
        local db = GetDB()
        return db and db.showUpgradeArrow
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showUpgradeArrow = v and true or false
        addon:RefreshConfigUIs()
    end)
    upgradeBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showLoot
    end
    PlaceCenteredCheckbox(upgradeBox, host, lootRowY, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, upgradeBox)
    y = y - 28

    local questItemsBox = CreateCheckbox(host, "Show quest items", function()
        local db = GetDB()
        return db and db.showQuestItems
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showQuestItems = v and true or false
        addon:RefreshConfigUIs()
    end)
    questItemsBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showLoot
    end
    PlaceCenteredCheckbox(questItemsBox, host, y, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, questItemsBox)
    y = y - 28

    local lootIconsBox = CreateCheckbox(host, "Show item icons", function()
        local db = GetDB()
        return db and db.showLootIcons
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showLootIcons = v and true or false
        addon:RefreshConfigUIs()
    end)
    lootIconsBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showLoot
    end
    PlaceCenteredCheckbox(lootIconsBox, host, y, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, lootIconsBox)
    y = y - 28

    local lootTotalsBox = CreateCheckbox(host, "Show totals", function()
        local db = GetDB()
        return db and db.showLootTotals
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showLootTotals = v and true or false
        addon:RefreshConfigUIs()
    end)
    lootTotalsBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showLoot
    end
    PlaceCenteredCheckbox(lootTotalsBox, host, y, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, lootTotalsBox)
    y = y - 28

    local moneyRowY = y
    local moneyBox = CreateCheckbox(host, "Money gains", function()
        local db = GetDB()
        return db and db.showMoney
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showMoney = v and true or false
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(moneyBox, host, moneyRowY, linkedLeftWidth, linkedLeftOffset)
    table.insert(ui.checkboxes, moneyBox)

    local moneyIconsBox = CreateCheckbox(host, "Show coin icons", function()
        local db = GetDB()
        return db and db.showMoneyIcons
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showMoneyIcons = v and true or false
        addon:RefreshConfigUIs()
    end)
    moneyIconsBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showMoney
    end
    PlaceCenteredCheckbox(moneyIconsBox, host, moneyRowY, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, moneyIconsBox)
    y = y - 28

    addBox("Currency gains", "showCurrency")

    y = y - 10

    addHeading("Scrolling")
    addBox("Enter / exit combat", "showCombat")
    addBox("Honor gains", "showHonor")

    local reputationRowY = y
    local reputationBox = CreateCheckbox(host, "Reputation changes", function()
        local db = GetDB()
        return db and db.showReputation
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showReputation = v and true or false
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(reputationBox, host, reputationRowY, linkedLeftWidth, linkedLeftOffset)
    table.insert(ui.checkboxes, reputationBox)

    local delveCompanionBox = CreateCheckbox(host, "Show Delve companion XP", function()
        local db = GetDB()
        return db and db.showDelveCompanionXP
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showDelveCompanionXP = v and true or false
        addon:RefreshConfigUIs()
    end)
    delveCompanionBox.enabledGetter = function()
        local db = GetDB()
        return db and db.showReputation
    end
    PlaceCenteredCheckbox(delveCompanionBox, host, reputationRowY, linkedRightWidth, linkedRightOffset)
    table.insert(ui.checkboxes, delveCompanionBox)
    y = y - 28

    addBox("Profession / skill gains", "showSkill")

    AddProfilePersistenceWarning(ui, host, 0, 38)
    page.contentHeight = 474
end

local function BuildLayoutPage(ui)
    local page = ui.pages.layout
    local host = CreateFrame("Frame", nil, page)
    host:SetPoint("TOP", page, "TOP", 16, 0)
    host:SetPoint("BOTTOM", page, "BOTTOM", 0, 0)
    host:SetWidth(560)

    local topY = -8
    local defaults = addon.GetDefaults and addon.GetDefaults() or {}
    local columnWidth = 250
    local leftX = -140
    local rightX = 140

    local function PlaceColumnHeader(header, y, xOffset)
        header:SetWidth(columnWidth)
        header:SetJustifyH("CENTER")
        header:SetPoint("TOP", host, "TOP", xOffset, y)
    end

    local function PlaceColumnControl(frame, y, xOffset)
        PlaceCenteredControl(frame, host, y, xOffset)
    end

    local function CreateResetPair(y, xOffset, resetPosFunc, resetScaleFunc)
        local resetPos = CreateButton(host, "Reset position", 110, resetPosFunc)
        PlaceColumnControl(resetPos, y, xOffset - 52)

        local resetScale = CreateButton(host, "Reset scale", 96, resetScaleFunc)
        resetScale:SetPoint("LEFT", resetPos, "RIGHT", 8, 0)
        return resetPos, resetScale
    end

    local resetBtn, testBtn = AddBottomActionButtons(host, function()
        addon:ResetLayoutTab()
    end, -78, 78, 10, 10)

    local anchorsBox = CreateCheckbox(host, "Show / unlock anchors", function()
        local db = GetDB()
        return db and db.showAnchors
    end, function(v)
        addon.SetAnchorUnlockState(v and true or false)
    end)
    PlaceCenteredCheckbox(anchorsBox, host, topY, 220, -120)
    table.insert(ui.checkboxes, anchorsBox)

    local miniBox = CreateCheckbox(host, "Show minimap button", function()
        local db = GetDB()
        return db and db.showMinimap
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.showMinimap = v and true or false
        addon:RefreshMinimap()
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(miniBox, host, topY, 220, 120)
    table.insert(ui.checkboxes, miniBox)

    local stackedHeaderY = topY - 52
    local stackedHeader = CreateLabel(host, "Stacked", "GameFontNormal")
    PlaceColumnHeader(stackedHeader, stackedHeaderY, leftX)

    local scrollingHeader = CreateLabel(host, "Scrolling", "GameFontNormal")
    PlaceColumnHeader(scrollingHeader, stackedHeaderY, rightX)

    local stackedY = stackedHeaderY - 38
    local scrollingY = stackedY

    local lootScaleSlider = CreateSlider(host, "Stacked message scale", 0.6, 2.0, 0.05, columnWidth,
        function()
            local db = GetDB()
            return db and db.lootScale
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.lootScale = tonumber(string.format("%.2f", v))
            if addon.LayoutLootMessages then addon.LayoutLootMessages() end
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%.2fx", v) end)
    PlaceColumnControl(lootScaleSlider, stackedY, leftX)
    table.insert(ui.sliders, lootScaleSlider)
    stackedY = stackedY - 44

    CreateResetPair(stackedY, leftX,
        function()
            local db = GetDB()
            if not db then return end
            db.stackAnchorX = defaults.stackAnchorX
            db.stackAnchorY = defaults.stackAnchorY
            addon:UpdateAnchorVisuals()
            addon:SyncActiveProfile()
            addon:RefreshConfigUIs()
        end,
        function()
            local db = GetDB()
            if not db then return end
            db.lootScale = defaults.lootScale
            if addon.LayoutLootMessages then addon.LayoutLootMessages() end
            addon:UpdateAnchorVisuals()
            addon:SyncActiveProfile()
            addon:RefreshConfigUIs()
        end)
    stackedY = stackedY - 58

    local lootDurationSlider = CreateSlider(host, "Stacked text duration", 1.0, 8.0, 0.25, columnWidth,
        function()
            local db = GetDB()
            return db and db.lootDuration
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.lootDuration = tonumber(string.format("%.2f", v))
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%.2fs", v) end)
    PlaceColumnControl(lootDurationSlider, stackedY, leftX)
    table.insert(ui.sliders, lootDurationSlider)
    stackedY = stackedY - 56

    local maxStackedSlider = CreateSlider(host, "Max notifications shown at once", 1, 12, 1, columnWidth,
        function()
            local db = GetDB()
            return db and db.maxStacked
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.maxStacked = math.floor(v + 0.5)
            if addon.PumpQueues then addon:PumpQueues() end
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%d", math.floor(v + 0.5)) end)
    PlaceColumnControl(maxStackedSlider, stackedY, leftX)
    table.insert(ui.sliders, maxStackedSlider)
    stackedY = stackedY - 56

    local stackPaddingSlider = CreateSlider(host, "Padding", -50, 40, 1, columnWidth,
        function()
            local db = GetDB()
            return db and db.stackPadding
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.stackPadding = math.floor(v + 0.5)
            if addon.LayoutLootMessages then addon.LayoutLootMessages() end
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%d", math.floor(v + 0.5)) end)
    PlaceColumnControl(stackPaddingSlider, stackedY, leftX)
    table.insert(ui.sliders, stackPaddingSlider)

    local scrollScaleSlider = CreateSlider(host, "Scrolling message scale", 0.6, 2.0, 0.05, columnWidth,
        function()
            local db = GetDB()
            return db and db.scrollScale
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.scrollScale = tonumber(string.format("%.2f", v))
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%.2fx", v) end)
    PlaceColumnControl(scrollScaleSlider, scrollingY, rightX)
    table.insert(ui.sliders, scrollScaleSlider)
    scrollingY = scrollingY - 44

    CreateResetPair(scrollingY, rightX,
        function()
            local db = GetDB()
            if not db then return end
            db.scrollAnchorX = defaults.scrollAnchorX
            db.scrollAnchorY = defaults.scrollAnchorY
            addon:UpdateAnchorVisuals()
            addon:SyncActiveProfile()
            addon:RefreshConfigUIs()
        end,
        function()
            local db = GetDB()
            if not db then return end
            db.scrollScale = defaults.scrollScale
            addon:UpdateAnchorVisuals()
            addon:SyncActiveProfile()
            addon:RefreshConfigUIs()
        end)
    scrollingY = scrollingY - 58

    local scrollDurationSlider = CreateSlider(host, "Scroll duration", 2.0, 8.0, 0.25, columnWidth,
        function()
            local db = GetDB()
            return db and db.scrollDuration
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.scrollDuration = tonumber(string.format("%.2f", v))
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%.2fs", v) end)
    PlaceColumnControl(scrollDurationSlider, scrollingY, rightX)
    table.insert(ui.sliders, scrollDurationSlider)
    scrollingY = scrollingY - 56

    local maxScrollSlider = CreateSlider(host, "Max notifications shown at once", 1, 12, 1, columnWidth,
        function()
            local db = GetDB()
            return db and db.maxScrollVisible
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.maxScrollVisible = math.floor(v + 0.5)
            if addon.PumpQueues then addon:PumpQueues() end
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%d", math.floor(v + 0.5)) end)
    PlaceColumnControl(maxScrollSlider, scrollingY, rightX)
    table.insert(ui.sliders, maxScrollSlider)
    scrollingY = scrollingY - 56

    local scrollPaddingSlider = CreateSlider(host, "Padding", -50, 40, 1, columnWidth,
        function()
            local db = GetDB()
            return db and db.scrollPadding
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.scrollPadding = math.floor(v + 0.5)
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%d", math.floor(v + 0.5)) end)
    PlaceColumnControl(scrollPaddingSlider, scrollingY, rightX)
    table.insert(ui.sliders, scrollPaddingSlider)

    local generalHeaderY = math.min(stackedY, scrollingY) - 74
    local fontHeader = CreateLabel(host, "General", "GameFontNormal")
    fontHeader:SetWidth(300)
    fontHeader:SetJustifyH("CENTER")
    fontHeader:SetPoint("TOP", host, "TOP", 0, generalHeaderY)

    local fontSlider = CreateSlider(host, "Base font size", 14, 36, 1, 300,
        function()
            local db = GetDB()
            return db and db.fontSize
        end,
        function(v)
            local db = GetDB()
            if not db then return end
            db.fontSize = math.floor(v + 0.5)
            if addon.LayoutLootMessages then addon.LayoutLootMessages() end
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        function(v) return string.format("%d", math.floor(v + 0.5)) end)
    PlaceCenteredControl(fontSlider, host, generalHeaderY - 38, 0)
    table.insert(ui.sliders, fontSlider)

    local warning = AddProfilePersistenceWarning(ui, host, 0, 36)
    warning:ClearAllPoints()
    warning:SetPoint("TOP", fontSlider.valueText, "BOTTOM", 0, -44)

    if resetBtn and testBtn then
        resetBtn:ClearAllPoints()
        resetBtn:SetPoint("TOP", warning, "BOTTOM", -78, -8)
        testBtn:ClearAllPoints()
        testBtn:SetPoint("LEFT", resetBtn, "RIGHT", 12, 0)
    end

    page.contentHeight = 620
end

local function BuildColorsPage(ui)
    local page = ui.pages.colors
    local host = CreateFrame("Frame", nil, page)
    host:SetPoint("TOP", page, "TOP", 0, 0)
    host:SetPoint("BOTTOM", page, "BOTTOM", 0, 0)
    host:SetWidth(560)

    local y = -8

    local resetBtn, testBtn = AddBottomActionButtons(host, function()
        addon:ResetColorsTab()
    end)
    y = y - 8

    for _, def in ipairs(COLOR_ROWS or {}) do
        local row = CreateColorRow(host, def)
        row:SetPoint("TOP", host, "TOP", 0, y)
        y = y - 30
        table.insert(ui.colorRows, row)
    end

    AddProfilePersistenceWarning(ui, host, 0, 52)
    page.contentHeight = 400
end

local function BuildCustomizePage(ui)
    local page = ui.pages.customize
    local host = CreateFrame("Frame", nil, page)
    host:SetPoint("TOP", page, "TOP", 16, 0)
    host:SetPoint("BOTTOM", page, "BOTTOM", 0, 0)
    host:SetWidth(560)

    local y = -8
    local defaults = addon.GetDefaults and addon.GetDefaults() or {}

    local resetBtn, testBtn = AddBottomActionButtons(host, function()
        addon:ResetCustomizeTab()
    end)

    local enterLabel = CreateLabel(host, "Enter combat text", "GameFontHighlight")
    enterLabel:SetWidth(300)
    enterLabel:SetJustifyH("CENTER")
    enterLabel:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 26

    local enterBox = CreateEditBox(host, 300,
        function() return GetCombatEnterText() end,
        function(v)
            local db = GetDB()
            if not db then return end
            v = tostring(v or ""):gsub("^%s+", ""):gsub("%s+$", "")
            db.combatEnterText = (v ~= "" and v) or defaults.combatEnterText
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        80)
    PlaceCenteredControl(enterBox, host, y, 0)
    table.insert(ui.editBoxes, enterBox)
    y = y - 52

    local leaveLabel = CreateLabel(host, "Leave combat text", "GameFontHighlight")
    leaveLabel:SetWidth(300)
    leaveLabel:SetJustifyH("CENTER")
    leaveLabel:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 26

    local leaveBox = CreateEditBox(host, 300,
        function() return GetCombatLeaveText() end,
        function(v)
            local db = GetDB()
            if not db then return end
            v = tostring(v or ""):gsub("^%s+", ""):gsub("%s+$", "")
            db.combatLeaveText = (v ~= "" and v) or defaults.combatLeaveText
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end,
        80)
    PlaceCenteredControl(leaveBox, host, y, 0)
    table.insert(ui.editBoxes, leaveBox)
    y = y - 58

    local filterHeader = CreateLabel(host, "Filters", "GameFontNormal")
    filterHeader:SetWidth(300)
    filterHeader:SetJustifyH("CENTER")
    filterHeader:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 28

    local greyBox = CreateCheckbox(host, "Hide grey (poor) loot", function()
        local db = GetDB()
        return db and db.hideGreys
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.hideGreys = v and true or false
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(greyBox, host, y, 280, 0)
    table.insert(ui.checkboxes, greyBox)
    y = y - 56

    local fontsHeader = CreateLabel(host, "Fonts", "GameFontNormal")
    fontsHeader:SetWidth(300)
    fontsHeader:SetJustifyH("CENTER")
    fontsHeader:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 30

    local individualFontsBox = CreateCheckbox(host, "Set fonts per notification type", function()
        local db = GetDB()
        return db and db.useIndividualFonts
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.useIndividualFonts = v and true or false
        addon:UpdateAnchorVisuals()
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(individualFontsBox, host, y, 320, 0)
    table.insert(ui.checkboxes, individualFontsBox)
    y = y - 40

    local globalFontLabel = CreateLabel(host, "Global font", "GameFontHighlight")
    globalFontLabel:SetWidth(300)
    globalFontLabel:SetJustifyH("CENTER")
    globalFontLabel:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 24

    local globalFontDropdown = CreateFontDropdown(host, 250,
        function()
            local db = GetDB()
            return db and db.globalFont
        end,
        function(value)
            local db = GetDB()
            if not db then return end
            db.globalFont = NormalizeFontKey(value)
            addon:UpdateAnchorVisuals()
            addon:RefreshConfigUIs()
        end)
    PlaceCenteredControl(globalFontDropdown, host, y, 0)
    table.insert(ui.fontRows, globalFontDropdown)
    y = y - 44

    local stripSymbolsBox = CreateCheckbox(host, "Strip symbols from auto-generated messages (may help with some fonts that don't include them)", function()
        local db = GetDB()
        return db and db.stripAutoSymbols
    end, function(v)
        local db = GetDB()
        if not db then return end
        db.stripAutoSymbols = v and true or false
        addon:UpdateAnchorVisuals()
        addon:RefreshConfigUIs()
    end)
    PlaceCenteredCheckbox(stripSymbolsBox, host, y, 360, 0)
    table.insert(ui.checkboxes, stripSymbolsBox)
    y = y - 54

    local fontRows = {}
    local fontRowDefs = {
        { role = "loot", label = "Loot" },
        { role = "money", label = "Money" },
        { role = "currency", label = "Currency" },
        { role = "combatEnter", label = "Combat Start" },
        { role = "combatLeave", label = "Combat End" },
        { role = "honor", label = "Honor" },
        { role = "repGain", label = "Rep Gain" },
        { role = "repLoss", label = "Rep Loss" },
        { role = "skill", label = "Skill" },
    }

    local leftX = -150
    local rightX = 150
    local rowWidth = 220
    local rowGap = 58
    for index, def in ipairs(fontRowDefs) do
        local row = CreateFontDropdownRow(host, def.label, rowWidth,
            function()
                local db = GetDB()
                return db and db[def.role .. "Font"]
            end,
            function(value)
                local db = GetDB()
                if not db then return end
                db[def.role .. "Font"] = NormalizeFontKey(value)
                addon:UpdateAnchorVisuals()
                addon:RefreshConfigUIs()
            end)
        local columnX = ((index % 2) == 1) and leftX or rightX
        local rowY = y - (math.floor((index - 1) / 2) * rowGap)
        row:SetPoint("TOP", host, "TOP", columnX, rowY)
        table.insert(ui.fontRows, row)
        table.insert(fontRows, row)
    end
    y = y - (math.ceil(#fontRowDefs / 2) * rowGap) - 12

    local profileWarning = AddProfilePersistenceWarning(ui, host, 0, 52)

    table.insert(ui.refreshers, function()
        local db = GetDB()
        local useIndividual = db and db.useIndividualFonts
        local targetHeight = useIndividual and 820 or 680

        if globalFontLabel then
            globalFontLabel:SetText("Global font")
            globalFontLabel:SetAlpha(useIndividual and 0.55 or 1)
        end
        SetDropdownEnabled(globalFontDropdown, not useIndividual)
        globalFontDropdown:SetAlpha(useIndividual and 0.7 or 1)
        for _, row in ipairs(fontRows) do
            row:SetShown(useIndividual and true or false)
            row:SetEnabled(useIndividual and true or false)
        end

        if page.contentHeight ~= targetHeight then
            page.contentHeight = targetHeight
            local width = math.max(560, ui.parent:GetWidth() - 70)
            page:SetSize(width, targetHeight)
            if ui.activePage == "customize" then
                ui.content:SetSize(width, targetHeight)
                if ui.scroll.UpdateScrollChildRect then
                    ui.scroll:UpdateScrollChildRect()
                end
            end
        end

        local warningY = useIndividual and 52 or 220
        local buttonsY = useIndividual and 18 or 186

        if profileWarning then
            profileWarning:ClearAllPoints()
            profileWarning:SetPoint("BOTTOM", host, "BOTTOM", 0, warningY)
        end
        if resetBtn then
            resetBtn:ClearAllPoints()
            resetBtn:SetPoint("BOTTOM", host, "BOTTOM", -78, buttonsY)
        end
    end)

    page.contentHeight = 680
end

local function BuildProfilesPage(ui)
    local page = ui.pages.profiles
    local host = CreateFrame("Frame", nil, page)
    host:SetPoint("TOP", page, "TOP", 8, 0)
    host:SetPoint("BOTTOM", page, "BOTTOM", 0, 0)
    host:SetWidth(560)

    local y = -8

    local header = CreateLabel(host, "Profiles", "GameFontNormal")
    header:SetPoint("TOP", host, "TOP", 0, y)
    header:SetWidth(560)
    header:SetJustifyH("CENTER")
    y = y - 40

    local activeLabel = CreateLabel(host, "Profile", "GameFontHighlight")
    activeLabel:SetWidth(300)
    activeLabel:SetJustifyH("CENTER")
    activeLabel:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 26

    local dropdown = CreateFrame("Frame", ADDON_NAME .. "ProfileDropdown", host, "UIDropDownMenuTemplate")
    dropdown:SetPoint("TOP", host, "TOP", 0, y)
    UIDropDownMenu_SetWidth(dropdown, 280)
    UIDropDownMenu_SetText(dropdown, DEFAULT_PROFILE_NAME)
    y = y - 56

    local saveBtn
    local deleteBtn

    local function refreshDropdownText()
        local db = GetDB()
        local current = db and db.lastProfile
        local profiles = addon:EnsureProfilesTable()
        if type(current) == "string" and current ~= "" and not IsReservedProfileName(current) and type(profiles[current]) == "string" and profiles[current] ~= "" then
            UIDropDownMenu_SetText(dropdown, current)
        else
            UIDropDownMenu_SetText(dropdown, DEFAULT_PROFILE_NAME)
        end
        SetDropdownDisplayTextToDefaultFont(dropdown)
    end

    local function refreshProfileButtons()
        if not deleteBtn then return end
        local db = GetDB()
        local current = db and db.lastProfile or DEFAULT_PROFILE_NAME
        local canDelete = type(current) == "string" and current ~= "" and not IsReservedProfileName(current)
        if canDelete then
            deleteBtn:Enable()
            deleteBtn:SetAlpha(1)
        else
            deleteBtn:Disable()
            deleteBtn:SetAlpha(0.55)
        end
    end

    UIDropDownMenu_Initialize(dropdown, function(self, level)
        if not level then return end

        do
            local db = GetDB()
            local info = UIDropDownMenu_CreateInfo()
            info.text = DEFAULT_PROFILE_NAME
            info.checked = (db and db.lastProfile == DEFAULT_PROFILE_NAME) and true or false
            info.func = function()
                CloseDropDownMenus()
                addon:ApplyProfile(DEFAULT_PROFILE_NAME)
                refreshDropdownText()
                refreshProfileButtons()
            end
            UIDropDownMenu_AddButton(info, level)
            StyleFontDropdownMenuButton(GetLatestDropdownListButton(level), nil, true)
        end

        local names = addon:GetSortedProfileNames()
        local db = GetDB()
        for _, name in ipairs(names) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = name
            info.checked = (db and db.lastProfile == name) and true or false
            info.func = function()
                CloseDropDownMenus()
                addon:ApplyProfile(name)
                refreshDropdownText()
                refreshProfileButtons()
            end
            UIDropDownMenu_AddButton(info, level)
            StyleFontDropdownMenuButton(GetLatestDropdownListButton(level), nil, true)
        end
    end)

    saveBtn = CreateButton(host, "Save new...", 120, function()
        CloseDropDownMenus()
        if StaticPopup_Show then
            StaticPopup_Show("LOOTBT_SAVE_PROFILE")
        end
    end)
    saveBtn:SetPoint("TOP", host, "TOP", -72, y)

    deleteBtn = CreateButton(host, "Delete profile", 120, function()
        CloseDropDownMenus()
        local db = GetDB()
        local current = db and db.lastProfile or DEFAULT_PROFILE_NAME
        if IsReservedProfileName(current) then
            if Print then
                Print(string.format("'%s' cannot be deleted.", DEFAULT_PROFILE_NAME))
            end
            return
        end
        if StaticPopup_Show then
            StaticPopup_Show("LOOTBT_DELETE_PROFILE", current, nil, current)
            return
        end
        local ok, err = addon:DeleteProfile(current)
        if not ok and err and Print then
            Print(err)
        end
    end)
    deleteBtn:SetPoint("TOP", host, "TOP", 72, y)
    y = y - 44

    table.insert(ui.refreshers, function()
        refreshDropdownText()
        refreshProfileButtons()
    end)

    local exportHeader = CreateLabel(host, "Export", "GameFontNormal")
    exportHeader:SetWidth(300)
    exportHeader:SetJustifyH("CENTER")
    exportHeader:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 26

    local exportBtn = CreateButton(host, "Export", 120, function()
        addon:ShowExportPopup()
    end)
    exportBtn:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 42

    local importHeader = CreateLabel(host, "Import", "GameFontNormal")
    importHeader:SetWidth(300)
    importHeader:SetJustifyH("CENTER")
    importHeader:SetPoint("TOP", host, "TOP", 0, y)
    y = y - 26

    local importBtn = CreateButton(host, "Import", 120, function()
        addon:ShowImportPopup()
    end)
    importBtn:SetPoint("TOP", host, "TOP", 0, y)

    local testBtn = CreateButton(host, "Test notifications", 140, function()
        addon:RunTest()
    end)
    testBtn:SetPoint("BOTTOM", host, "BOTTOM", 0, 18)

    AddProfilePersistenceWarning(ui, host, 0, 58)
    page.contentHeight = 400
end

function addon:BuildConfigUI(parent, isStandalone)
    local ui = CreateConfigShell(parent, isStandalone)

    BuildNotificationsPage(ui)
    BuildLayoutPage(ui)
    BuildColorsPage(ui)
    BuildCustomizePage(ui)
    BuildProfilesPage(ui)

    function ui:Refresh()
        for _, box in ipairs(self.checkboxes) do if box.Refresh then box:Refresh() end end
        for _, slider in ipairs(self.sliders) do if slider.Refresh then slider:Refresh() end end
        for _, row in ipairs(self.colorRows) do if row.Refresh then row:Refresh() end end
        for _, box in ipairs(self.editBoxes) do if box.Refresh then box:Refresh() end end
        for _, row in ipairs(self.fontRows) do if row.Refresh then row:Refresh() end end
        for _, fn in ipairs(self.refreshers) do if type(fn) == "function" then pcall(fn) end end
    end

    ui.ShowPage("notifications")
    ui:Refresh()
    table.insert(configUIs, ui)
    return ui
end

function addon:RefreshConfigUIs()
    for _, ui in ipairs(configUIs) do
        if ui and ui.Refresh then
            ui:Refresh()
        end
    end
    self:UpdateAnchorVisuals()
end

function addon:GetStandaloneOptionsPanel()
    return optionsPanel
end

function addon:CreateStandaloneOptions()
    if optionsPanel then return optionsPanel end
    local panel = CreateFrame("Frame", ADDON_NAME .. "Options", UIParent, backdropTemplate)
    panel:SetSize(680, 660)
    if panel.SetResizeBounds then
        panel:SetResizeBounds(620, 520, 1100, 900)
    else
        if panel.SetMinResize then panel:SetMinResize(620, 520) end
        if panel.SetMaxResize then panel:SetMaxResize(1100, 900) end
    end
    panel:SetResizable(true)
    panel:SetPoint("CENTER")
    panel:SetFrameStrata("DIALOG")
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:SetClampedToScreen(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", function(self)
        if not InCombatLockdown() then self:StartMoving() end
    end)
    panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    panel:Hide()
    CreateBackdrop(panel)
    if panel.SetBackdropColor then panel:SetBackdropColor(0.05, 0.05, 0.07, 0.96) end

    local resize = CreateFrame("Button", nil, panel)
    resize:SetSize(18, 18)
    resize:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -4, 4)
    resize:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resize:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resize:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")

    local function FinishResize()
        if not panel.isLootBTResizing then return end
        panel.isLootBTResizing = nil
        resize:SetScript("OnUpdate", nil)
        if panel.ui and panel.ui.activePage and panel.ui.ShowPage then
            panel.ui:Refresh()
            panel.ui.ShowPage(panel.ui.activePage)
        end
    end

    resize:SetScript("OnMouseDown", function()
        if InCombatLockdown() then return end

        local cursorX, cursorY = GetCursorPosition()
        local scale = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
        cursorX = cursorX / scale
        cursorY = cursorY / scale

        panel.isLootBTResizing = true
        panel.lootBTResizeStartCursorX = cursorX
        panel.lootBTResizeStartCursorY = cursorY
        panel.lootBTResizeStartWidth = panel:GetWidth()
        panel.lootBTResizeStartHeight = panel:GetHeight()
        panel.lootBTResizeStartLeft = panel:GetLeft()
        panel.lootBTResizeStartTop = panel:GetTop()

        resize:SetScript("OnUpdate", function()
            if not panel.isLootBTResizing then return end

            local currentX, currentY = GetCursorPosition()
            currentX = currentX / scale
            currentY = currentY / scale

            local minWidth, minHeight = 620, 520
            local maxWidth, maxHeight = 1100, 900
            local newWidth = Clamp((panel.lootBTResizeStartWidth or panel:GetWidth()) + (currentX - (panel.lootBTResizeStartCursorX or currentX)), minWidth, maxWidth)
            local newHeight = Clamp((panel.lootBTResizeStartHeight or panel:GetHeight()) - (currentY - (panel.lootBTResizeStartCursorY or currentY)), minHeight, maxHeight)
            local left = panel.lootBTResizeStartLeft or panel:GetLeft()
            local top = panel.lootBTResizeStartTop or panel:GetTop()

            panel:ClearAllPoints()
            panel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
            panel:SetSize(newWidth, newHeight)
        end)
    end)
    resize:SetScript("OnMouseUp", FinishResize)
    panel:HookScript("OnHide", FinishResize)
    panel.resizeButton = resize

    panel.ui = self:BuildConfigUI(panel, true)
    optionsPanel = panel
    return panel
end

function addon:CreateSettingsPanel()
    if settingsPanel then return settingsPanel end
    local panel = CreateFrame("Frame", ADDON_NAME .. "SettingsPanel", UIParent)
    panel.name = "LootBT"
    panel:SetSize(760, 620)
    panel.ui = self:BuildConfigUI(panel, false)
    settingsPanel = panel

    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        settingsCategory = Settings.RegisterCanvasLayoutCategory(panel, "LootBT")
        Settings.RegisterAddOnCategory(settingsCategory)
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
        settingsCategory = panel
    end

    return panel
end

function addon:ToggleOptions(force)
    local panel = self:CreateStandaloneOptions()
    if force == false then
        panel:Hide()
        return
    end
    if InCombatLockdown() then
        if Print then Print("Options cannot be opened in combat.") end
        panel:Hide()
        return
    end
    if force == true then
        panel:Show()
    elseif panel:IsShown() then
        panel:Hide()
    else
        panel:Show()
    end
    panel:Raise()
    self:RefreshConfigUIs()
end

function addon:OpenSettingsCategory()
    self:CreateSettingsPanel()
    if Settings and Settings.OpenToCategory and settingsCategory then
        if settingsCategory.GetID then
            pcall(Settings.OpenToCategory, settingsCategory:GetID())
        else
            pcall(Settings.OpenToCategory, "LootBT")
        end
    elseif InterfaceOptionsFrame_OpenToCategory then
        InterfaceOptionsFrame_OpenToCategory("LootBT")
        InterfaceOptionsFrame_OpenToCategory("LootBT")
    else
        self:ToggleOptions(true)
    end
end
