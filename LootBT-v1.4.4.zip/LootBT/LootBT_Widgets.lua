local ADDON_NAME, ns = ...
ns = ns or {}

local addon = ns.addon
local U = ns.U or {}
if not addon then
    return
end

local backdropTemplate = BackdropTemplateMixin and "BackdropTemplate" or nil
local BuildFontCatalog = U.BuildFontCatalog
local NormalizeFontKey = U.NormalizeFontKey
local GetFontLabelByKey = U.GetFontLabelByKey
local GetColorForKey = U.GetColorForKey
local SetColorForKey = U.SetColorForKey
local SetMessageFont = U.SetMessageFont
local GetMoneyPreviewText = U.GetMoneyPreviewText
local GetLootPreviewText = U.GetLootPreviewText
local ShouldUseSimpleAutoSymbols = U.ShouldUseSimpleAutoSymbols
local FormatCurrencyDisplayText = U.FormatCurrencyDisplayText
local FormatHonorDisplayText = U.FormatHonorDisplayText
local FormatReputationDisplayText = U.FormatReputationDisplayText
local GetCombatEnterText = U.GetCombatEnterText
local GetCombatLeaveText = U.GetCombatLeaveText
local CreateBackdrop = U.CreateBackdrop
local Clamp = U.Clamp

local DEFAULT_FONT_KEY = "default"
local FONT_DROPDOWN_VISIBLE_ITEMS = 18
local sliderCounter = 0
local dropdownCounter = 0

local function GetCurrentColorPickerRGB()
    if ColorPickerFrame and ColorPickerFrame.GetColorRGB then
        return ColorPickerFrame:GetColorRGB()
    end
    if ColorPickerFrame and ColorPickerFrame.Content and ColorPickerFrame.Content.ColorPicker and ColorPickerFrame.Content.ColorPicker.GetColorRGB then
        return ColorPickerFrame.Content.ColorPicker:GetColorRGB()
    end
    return 1, 1, 1
end

local function OpenColorPickerForKey(key)
    if not ColorPickerFrame then return end
    local r, g, b = GetColorForKey(key)

    local function apply()
        local nr, ng, nb = GetCurrentColorPickerRGB()
        SetColorForKey(key, nr, ng, nb)
        addon:SyncActiveProfile()
        addon:RefreshConfigUIs()
        addon:UpdateAnchorVisuals()
    end

    local function cancel(previous)
        if type(previous) == "table" then
            SetColorForKey(key, previous.r or previous[1] or r, previous.g or previous[2] or g, previous.b or previous[3] or b)
        else
            SetColorForKey(key, r, g, b)
        end
        addon:SyncActiveProfile()
        addon:RefreshConfigUIs()
        addon:UpdateAnchorVisuals()
    end

    if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({
            r = r,
            g = g,
            b = b,
            hasOpacity = false,
            swatchFunc = apply,
            cancelFunc = cancel,
            previousValues = { r = r, g = g, b = b },
        })
    else
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.opacity = 1
        ColorPickerFrame.previousValues = { r, g, b }
        ColorPickerFrame.func = apply
        ColorPickerFrame.cancelFunc = cancel
        if ColorPickerFrame.SetColorRGB then
            ColorPickerFrame:SetColorRGB(r, g, b)
        end
        ColorPickerFrame:Show()
    end
end

local function CreateLabel(parent, text, template)
    local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    fs:SetText(text)
    return fs
end

local function CreateButton(parent, text, width, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width or 110, 22)
    b:SetText(text)
    b:SetScript("OnClick", function()
        if onClick then onClick() end
    end)
    return b
end

local function CreateCheckbox(parent, label, getter, setter)
    local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    box.label = box:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    box.label:SetPoint("LEFT", box, "RIGHT", 4, 1)
    box.label:SetText(label)
    box.getter = getter
    box.setter = setter
    box.SetEnabledState = function(self, enabled)
        enabled = enabled and true or false
        if enabled then
            if self.Enable then self:Enable() end
        else
            if self.Disable then self:Disable() end
        end
        self:SetAlpha(enabled and 1 or 0.6)
        if self.label then
            self.label:SetAlpha(enabled and 1 or 0.5)
        end
    end
    box:SetScript("OnClick", function(self)
        if self.setter then
            self.setter(self:GetChecked() and true or false)
        end
        addon:SyncActiveProfile()
    end)
    box.Refresh = function(self)
        if self.getter then
            self:SetChecked(self.getter() and true or false)
        end
        if self.enabledGetter then
            self:SetEnabledState(self.enabledGetter())
        else
            self:SetEnabledState(true)
        end
    end
    return box
end

local function CreateEditBox(parent, width, getter, setter, maxLetters)
    local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    box:SetSize(width or 260, 30)
    box:SetAutoFocus(false)
    box:SetMaxLetters(maxLetters or 80)
    box.getter = getter
    box.setter = setter

    box:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    box:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        if self.Refresh then self:Refresh() end
    end)
    box:SetScript("OnEditFocusLost", function(self)
        if self.setter then
            self.setter(self:GetText() or "")
        end
        addon:SyncActiveProfile()
        if self.Refresh then self:Refresh() end
    end)

    box.Refresh = function(self)
        local value = self.getter and self.getter() or ""
        value = tostring(value or "")
        if self:GetText() ~= value then
            self:SetText(value)
        end
    end

    return box
end

local function SetDropdownEnabled(dropdown, enabled)
    if not dropdown then return end
    if UIDropDownMenu_EnableDropDown and UIDropDownMenu_DisableDropDown then
        if enabled then
            UIDropDownMenu_EnableDropDown(dropdown)
        else
            UIDropDownMenu_DisableDropDown(dropdown)
        end
    end

    local name = dropdown.GetName and dropdown:GetName() or nil
    local button = name and _G[name .. "Button"] or nil
    local textObj = name and _G[name .. "Text"] or nil
    if button then
        button:SetEnabled(enabled and true or false)
        button:SetAlpha(enabled and 1 or 0.45)
    end
    if textObj then
        textObj:SetAlpha(enabled and 1 or 0.55)
    end
    dropdown:SetAlpha(enabled and 1 or 0.7)
end

local function ReopenFontDropdownMenu(dropdown)
    if not dropdown or not ToggleDropDownMenu then return end
    CloseDropDownMenus()

    local function reopen()
        if dropdown and dropdown:IsShown() then
            ToggleDropDownMenu(1, nil, dropdown, dropdown, 0, 0)
        end
    end

    if C_Timer and C_Timer.After then
        C_Timer.After(0, reopen)
    else
        reopen()
    end
end

local function GetLatestDropdownListButton(level)
    local listFrame = _G["DropDownList" .. tostring(level or 1)]
    local index = listFrame and listFrame.numButtons
    return (listFrame and index) and _G[listFrame:GetName() .. "Button" .. index] or nil
end

local function HideAllDropdownDeleteButtons()
    local maxLevels = UIDROPDOWNMENU_MAXLEVELS or 2
    local maxButtons = UIDROPDOWNMENU_MAXBUTTONS or 32

    for level = 1, maxLevels do
        local listFrame = _G["DropDownList" .. tostring(level)]
        if listFrame then
            local buttonCount = math.max(listFrame.numButtons or 0, maxButtons)
            for index = 1, buttonCount do
                local button = _G[listFrame:GetName() .. "Button" .. index]
                if button and button.lootBTDelete then
                    button.lootBTDelete.profileName = nil
                    button.lootBTDelete:Hide()
                end
            end
        end
    end
end

local function GetDropdownButtonFontString(button)
    if not button then return nil end
    return button:GetFontString() or _G[((button.GetName and button:GetName()) or "") .. "NormalText"]
end

local function ResetDropdownMenuButtonFont(button)
    local fontString = GetDropdownButtonFontString(button)
    if not fontString then return end
    fontString:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 12, "")
    button.lootBTOriginalFont = nil
end

local function ResetDropdownListFonts(level)
    local listFrame = _G["DropDownList" .. tostring(level or 1)]
    if not listFrame then return end
    local buttonCount = math.max(listFrame.numButtons or 0, UIDROPDOWNMENU_MAXBUTTONS or 32)
    for index = 1, buttonCount do
        local button = _G[listFrame:GetName() .. "Button" .. index]
        if button then
            ResetDropdownMenuButtonFont(button)
        end
    end
end

local dropdownListFontHooksReady = false
local dropdownMenuToggleHookReady = false

local function EnsureDropdownMenuToggleHook()
    if dropdownMenuToggleHookReady then return end
    if not hooksecurefunc or not ToggleDropDownMenu then return end
    dropdownMenuToggleHookReady = true

    hooksecurefunc("ToggleDropDownMenu", function(level, value, dropdownFrame)
        if dropdownFrame and dropdownFrame.lootBTIsFontDropdown then return end
        local maxLevels = UIDROPDOWNMENU_MAXLEVELS or 2
        for resetLevel = 1, maxLevels do
            ResetDropdownListFonts(resetLevel)
        end
    end)
end

local function EnsureDropdownListFontHooks()
    if dropdownListFontHooksReady then return end
    dropdownListFontHooksReady = true
    EnsureDropdownMenuToggleHook()

    local maxLevels = UIDROPDOWNMENU_MAXLEVELS or 2
    for level = 1, maxLevels do
        local hookLevel = level
        local listFrame = _G["DropDownList" .. tostring(hookLevel)]
        if listFrame and listFrame.HookScript then
            listFrame:HookScript("OnHide", function()
                ResetDropdownListFonts(hookLevel)
            end)
        end
    end
end

local function StyleFontDropdownMenuButton(button, fontPath, useDefaultFont)
    if not button then return end

    local fontString = GetDropdownButtonFontString(button)
    if not fontString then return end

    local targetFont = (not useDefaultFont and type(fontPath) == "string" and fontPath ~= "" and fontPath) or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    local ok = fontString:SetFont(targetFont, 12, "")
    if not ok and targetFont ~= (STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF") then
        fontString:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 12, "")
    end
end

local function SetDropdownDisplayTextToDefaultFont(dropdown)
    if not dropdown or not dropdown.GetName then return end
    local name = dropdown:GetName()
    if not name or name == "" then return end
    local textObj = _G[name .. "Text"]
    if not textObj then return end
    textObj:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 12, "")
end

local function CreateFontDropdown(parent, width, getter, setter)
    EnsureDropdownListFontHooks()
    dropdownCounter = dropdownCounter + 1
    local name = ADDON_NAME .. "FontDropdown" .. dropdownCounter
    local dropdown = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
    dropdown.lootBTIsFontDropdown = true
    dropdown.width = width or 220
    dropdown.getter = getter
    dropdown.setter = setter
    dropdown.menuOffset = 0
    dropdown.visibleItems = FONT_DROPDOWN_VISIBLE_ITEMS

    UIDropDownMenu_SetWidth(dropdown, dropdown.width)
    UIDropDownMenu_Initialize(dropdown, function(self, level)
        if not level then return end
        HideAllDropdownDeleteButtons()
        ResetDropdownListFonts(level)
        local options = BuildFontCatalog and BuildFontCatalog() or nil
        options = type(options) == "table" and options or {}

        local totalOptions = #options
        if totalOptions <= 0 then
            local info = UIDropDownMenu_CreateInfo()
            info.text = "No fonts found"
            info.disabled = true
            info.notCheckable = true
            UIDropDownMenu_AddButton(info, level)
            return
        end

        local visibleCount = math.min(dropdown.visibleItems or FONT_DROPDOWN_VISIBLE_ITEMS, totalOptions)
        local maxOffset = math.max(0, totalOptions - visibleCount)
        local offset = Clamp(tonumber(dropdown.menuOffset) or 0, 0, maxOffset)
        local selectedKey = dropdown.getter and NormalizeFontKey(dropdown.getter()) or DEFAULT_FONT_KEY
        local pageStep = math.max(1, visibleCount - 2)

        dropdown.menuOffset = offset

        if totalOptions > visibleCount and offset > 0 then
            local info = UIDropDownMenu_CreateInfo()
            info.text = "Scroll up"
            info.notCheckable = true
            info.func = function()
                dropdown.menuOffset = Clamp((dropdown.menuOffset or 0) - pageStep, 0, maxOffset)
                ReopenFontDropdownMenu(dropdown)
            end
            UIDropDownMenu_AddButton(info, level)
            StyleFontDropdownMenuButton(GetLatestDropdownListButton(level), nil, true)
        end

        local startIndex = offset + 1
        local endIndex = math.min(totalOptions, startIndex + visibleCount - 1)
        for index = startIndex, endIndex do
            local option = options[index]
            local optionIndex = index
            local info = UIDropDownMenu_CreateInfo()
            info.text = option.label
            info.checked = selectedKey == option.key
            info.func = function()
                dropdown.menuOffset = Clamp(optionIndex - math.floor(visibleCount / 2) - 1, 0, maxOffset)
                if dropdown.setter then
                    dropdown.setter(option.key)
                end
                addon:RefreshConfigUIs()
                addon:SyncActiveProfile()
                CloseDropDownMenus()
            end
            UIDropDownMenu_AddButton(info, level)
            StyleFontDropdownMenuButton(GetLatestDropdownListButton(level), option.path)
        end

        if totalOptions > visibleCount and endIndex < totalOptions then
            local info = UIDropDownMenu_CreateInfo()
            info.text = "Scroll down"
            info.notCheckable = true
            info.func = function()
                dropdown.menuOffset = Clamp((dropdown.menuOffset or 0) + pageStep, 0, maxOffset)
                ReopenFontDropdownMenu(dropdown)
            end
            UIDropDownMenu_AddButton(info, level)
            StyleFontDropdownMenuButton(GetLatestDropdownListButton(level), nil, true)
        end
    end)

    dropdown.Refresh = function(self)
        if BuildFontCatalog then
            BuildFontCatalog()
        end
        UIDropDownMenu_SetWidth(self, self.width)
        local key = self.getter and self.getter() or DEFAULT_FONT_KEY
        UIDropDownMenu_SetText(self, GetFontLabelByKey(key))
    end

    return dropdown
end

local function CreateFontDropdownRow(parent, labelText, width, getter, setter)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize((width or 220) + 20, 54)

    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.label:SetPoint("TOP", row, "TOP", 0, 0)
    row.label:SetText(labelText)
    row.label:SetJustifyH("CENTER")

    row.dropdown = CreateFontDropdown(row, width or 220, getter, setter)
    row.dropdown:SetPoint("TOP", row.label, "BOTTOM", 0, -4)

    row.SetEnabled = function(self, enabled)
        self.label:SetAlpha(enabled and 1 or 0.55)
        SetDropdownEnabled(self.dropdown, enabled)
    end

    row.Refresh = function(self)
        self.dropdown:Refresh()
    end

    return row
end

local function CreateSlider(parent, label, minVal, maxVal, step, width, getter, setter, formatter)
    sliderCounter = sliderCounter + 1
    local name = ADDON_NAME .. "Slider" .. sliderCounter
    local slider = CreateFrame("Slider", name, parent, "OptionsSliderTemplate")
    slider:SetMinMaxValues(minVal, maxVal)
    slider:SetValueStep(step)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    slider:SetWidth(width or 300)
    slider:SetHeight(16)
    slider.getter = getter
    slider.setter = setter
    slider.formatter = formatter

    local text = _G[name .. "Text"]
    local low = _G[name .. "Low"]
    local high = _G[name .. "High"]
    if text then
        text:ClearAllPoints()
        text:SetPoint("BOTTOM", slider, "TOP", 0, 8)
        text:SetText(label)
    end
    if low then low:SetText("") end
    if high then high:SetText("") end

    slider.valueText = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    slider.valueText:SetPoint("TOP", slider, "BOTTOM", 0, -2)

    slider:SetScript("OnValueChanged", function(self, value)
        if self._ignore then return end
        if self.setter then self.setter(value) end
        addon:SyncActiveProfile()
        local display = self.formatter and self.formatter(value) or tostring(value)
        self.valueText:SetText(display)
    end)

    slider.Refresh = function(self)
        local value = self.getter and self.getter() or minVal
        self._ignore = true
        self:SetValue(value)
        self._ignore = false
        local display = self.formatter and self.formatter(value) or tostring(value)
        self.valueText:SetText(display)
    end

    return slider
end

local function CreateColorRow(parent, def)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(520, 24)

    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.label:SetPoint("LEFT", 0, 0)
    row.label:SetWidth(120)
    row.label:SetJustifyH("LEFT")
    row.label:SetText(def.label)

    row.swatch = CreateFrame("Button", nil, row, backdropTemplate)
    row.swatch:SetSize(22, 22)
    row.swatch:SetPoint("LEFT", row.label, "RIGHT", 8, 0)
    CreateBackdrop(row.swatch)
    row.swatch:SetScript("OnClick", function() OpenColorPickerForKey(def.key) end)

    row.preview = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.preview:SetPoint("LEFT", row.swatch, "RIGHT", 10, 0)
    row.preview:SetWidth(340)
    row.preview:SetJustifyH("LEFT")
    SetMessageFont(row.preview, 0.9, def.key)
    row.preview:SetText(def.sample)

    row.Refresh = function(self)
        local r, g, b = GetColorForKey(def.key)
        if self.swatch.SetBackdropColor then
            self.swatch:SetBackdropColor(r, g, b, 1)
            self.swatch:SetBackdropBorderColor(1, 1, 1, 0.85)
        end
        local sample = def.sample
        if def.key == "combatEnter" then
            sample = GetCombatEnterText()
        elseif def.key == "combatLeave" then
            sample = GetCombatLeaveText()
        elseif def.key == "money" then
            sample = GetMoneyPreviewText()
        elseif def.key == "loot" then
            sample = GetLootPreviewText and GetLootPreviewText() or def.sample
        elseif def.key == "currency" then
            sample = FormatCurrencyDisplayText("Valorstones", 5, 1245)
        elseif def.key == "honor" then
            sample = FormatHonorDisplayText(25)
        elseif def.key == "repGain" then
            sample = FormatReputationDisplayText("Guild Rep +125", false)
        elseif def.key == "repLoss" then
            sample = FormatReputationDisplayText("Guild Rep -125", true)
        end
        self.preview:SetText(sample)
        self.preview:SetTextColor(r, g, b)
        SetMessageFont(self.preview, 0.9, def.key)
    end

    return row
end

U.CreateLabel = CreateLabel
U.CreateButton = CreateButton
U.CreateCheckbox = CreateCheckbox
U.CreateEditBox = CreateEditBox
U.SetDropdownEnabled = SetDropdownEnabled
U.SetDropdownDisplayTextToDefaultFont = SetDropdownDisplayTextToDefaultFont
U.CreateFontDropdown = CreateFontDropdown
U.CreateFontDropdownRow = CreateFontDropdownRow
U.CreateSlider = CreateSlider
U.CreateColorRow = CreateColorRow
U.HideAllDropdownDeleteButtons = HideAllDropdownDeleteButtons
U.GetLatestDropdownListButton = GetLatestDropdownListButton
U.StyleFontDropdownMenuButton = StyleFontDropdownMenuButton
